/**
 * Admin Bank Integrations Management Page
 * 
 * This page allows administrators to manage bank integrations and monitor their status.
 */

import React, { useState } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { adminApi } from "@/lib/adminApi";
import { authApi } from "@/lib/api";
import { 
  AlertCircle, 
  AlertTriangle, 
  Building as Bank, 
  CheckCircle, 
  Clock, 
  ExternalLink, 
  Info, 
  Loader2, 
  RefreshCw, 
  Settings, 
  Shield, 
  Users 
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AdminLayout } from "../../components/layouts/AdminLayout";
// Import toast functionality
import { toast } from "@/components/ui/use-toast";

// Create a hook-like interface for toast
const useToast = () => ({ toast });

// Status badge component
const StatusBadge = ({ status }: { status: string }) => {
  switch (status) {
    case 'active':
    case 'operational':
      return <Badge className="bg-green-500 hover:bg-green-600">{status}</Badge>;
    case 'maintenance':
    case 'degraded':
      return <Badge className="bg-amber-500 hover:bg-amber-600">{status}</Badge>;
    case 'deprecated':
    case 'outage':
      return <Badge className="bg-red-500 hover:bg-red-600">{status}</Badge>;
    case 'disabled':
      return <Badge variant="outline">{status}</Badge>;
    default:
      return <Badge variant="secondary">{status}</Badge>;
  }
};

// Status icon component
const StatusIcon = ({ status }: { status: string }) => {
  switch (status) {
    case 'active':
    case 'operational':
      return <CheckCircle className="h-5 w-5 text-green-500" />;
    case 'maintenance':
    case 'degraded':
      return <AlertTriangle className="h-5 w-5 text-amber-500" />;
    case 'deprecated':
    case 'outage':
      return <AlertCircle className="h-5 w-5 text-red-500" />;
    case 'disabled':
      return <Info className="h-5 w-5 text-gray-400" />;
    default:
      return <Info className="h-5 w-5 text-blue-500" />;
  }
};

// Format date
const formatDate = (dateString: string) => {
  const date = new Date(dateString);
  return new Intl.DateTimeFormat('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    hour12: true
  }).format(date);
};

export default function AdminIntegrationsPage() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedIntegration, setSelectedIntegration] = useState<any>(null);
  const [newStatus, setNewStatus] = useState<string>("");
  
  // Check if admin is authenticated
  React.useEffect(() => {
    if (!authApi.isAdminAuthenticated()) {
      navigate('/admin/login');
    }
  }, [navigate]);
  
  // Fetch bank integrations
  const { 
    data: integrations = [], 
    isLoading: isLoadingIntegrations,
    error: integrationsError,
    refetch: refetchIntegrations
  } = useQuery({
    queryKey: ['bankIntegrations'],
    queryFn: () => adminApi.getBankIntegrations(),
    enabled: authApi.isAdminAuthenticated()
  });
  
  // Update integration status mutation
  const updateStatusMutation = useMutation({
    mutationFn: ({ id, status }: { id: string; status: string }) => 
      adminApi.updateIntegrationStatus(id, status as any),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['bankIntegrations'] });
      setSelectedIntegration(null);
      toast({
        title: "Integration Updated",
        description: "The integration status has been successfully updated",
        variant: "default"
      });
    },
    onError: (error: any) => {
      toast({
        title: "Update Failed",
        description: error.message || "Failed to update integration status",
        variant: "destructive"
      });
    }
  });
  
  // Handle status update
  const handleStatusUpdate = () => {
    if (selectedIntegration && newStatus) {
      updateStatusMutation.mutate({ 
        id: selectedIntegration.id, 
        status: newStatus 
      });
    }
  };
  
  // Open status dialog
  const openStatusDialog = (integration: any) => {
    setSelectedIntegration(integration);
    setNewStatus(integration.status);
  };
  
  return (
    <AdminLayout>
      <div className="container mx-auto py-6 space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold">Bank Integrations</h1>
          <Button 
            variant="outline" 
            onClick={() => refetchIntegrations()}
            disabled={isLoadingIntegrations}
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${isLoadingIntegrations ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>
        
        {integrationsError ? (
          <div className="bg-red-900/20 border border-red-800 rounded-lg p-4 text-red-400">
            <div className="flex items-center">
              <AlertCircle className="h-5 w-5 mr-2" />
              <span>Failed to load bank integrations</span>
            </div>
          </div>
        ) : (
          <Tabs defaultValue="overview">
            <TabsList className="mb-6">
              <TabsTrigger value="overview">
                <Info className="h-4 w-4 mr-2" />
                Overview
              </TabsTrigger>
              <TabsTrigger value="status">
                <Shield className="h-4 w-4 mr-2" />
                Status
              </TabsTrigger>
              <TabsTrigger value="usage">
                <Users className="h-4 w-4 mr-2" />
                Usage
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="overview">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {isLoadingIntegrations ? (
                  // Loading skeletons
                  Array.from({ length: 6 }).map((_, i) => (
                    <Card key={`skeleton-${i}`}>
                      <CardHeader>
                        <Skeleton className="h-6 w-48" />
                        <Skeleton className="h-4 w-72 mt-2" />
                      </CardHeader>
                      <CardContent>
                        <Skeleton className="h-12 w-full" />
                      </CardContent>
                      <CardFooter>
                        <Skeleton className="h-10 w-full" />
                      </CardFooter>
                    </Card>
                  ))
                ) : (
                  integrations.map((integration: any) => (
                    <Card key={integration.id}>
                      <CardHeader>
                        <div className="flex justify-between items-center">
                          <CardTitle className="flex items-center">
                            <Bank className="h-5 w-5 mr-2 text-primary" />
                            {integration.displayName}
                          </CardTitle>
                          <StatusBadge status={integration.status} />
                        </div>
                        <CardDescription>{integration.description}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3 text-sm">
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Provider:</span>
                            <span className="font-medium">{integration.provider}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">API Version:</span>
                            <span className="font-medium">{integration.apiVersion}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Last Updated:</span>
                            <span className="font-medium">{formatDate(integration.updatedAt)}</span>
                          </div>
                        </div>
                      </CardContent>
                      <CardFooter>
                        <div className="flex space-x-2 w-full">
                          <Button 
                            variant="outline" 
                            className="flex-1"
                            onClick={() => openStatusDialog(integration)}
                          >
                            <Settings className="h-4 w-4 mr-2" />
                            Manage
                          </Button>
                          <Button 
                            variant="outline" 
                            size="icon"
                            asChild
                          >
                            <a href={integration.documentationUrl} target="_blank" rel="noopener noreferrer">
                              <ExternalLink className="h-4 w-4" />
                            </a>
                          </Button>
                        </div>
                      </CardFooter>
                    </Card>
                  ))
                )}
              </div>
            </TabsContent>
            
            <TabsContent value="status">
              <Card>
                <CardHeader>
                  <CardTitle>Integration Health Status</CardTitle>
                  <CardDescription>
                    Current operational status of all bank integrations
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-gray-800">
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Provider</th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Status</th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Response Time</th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Last Checked</th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Message</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-800">
                        {isLoadingIntegrations ? (
                          Array.from({ length: 6 }).map((_, i) => (
                            <tr key={`status-skeleton-${i}`}>
                              <td className="px-4 py-3"><Skeleton className="h-4 w-32" /></td>
                              <td className="px-4 py-3"><Skeleton className="h-4 w-24" /></td>
                              <td className="px-4 py-3"><Skeleton className="h-4 w-16" /></td>
                              <td className="px-4 py-3"><Skeleton className="h-4 w-32" /></td>
                              <td className="px-4 py-3"><Skeleton className="h-4 w-48" /></td>
                            </tr>
                          ))
                        ) : (
                          integrations.map((integration: any) => {
                            // Simulate health status data
                            const status = integration.status === 'active' ? 'operational' : 
                                          integration.status === 'maintenance' ? 'degraded' : 'outage';
                            const responseTime = integration.status === 'active' ? Math.floor(Math.random() * 200) + 50 : null;
                            const lastChecked = new Date().toISOString();
                            const message = status === 'operational' ? 'All systems operational' :
                                          status === 'degraded' ? 'Experiencing intermittent issues' : 'Service unavailable';
                            
                            return (
                              <tr key={`status-${integration.id}`} className="hover:bg-gray-800/50">
                                <td className="px-4 py-3">
                                  <div className="flex items-center">
                                    <StatusIcon status={status} />
                                    <span className="ml-2">{integration.displayName}</span>
                                  </div>
                                </td>
                                <td className="px-4 py-3">
                                  <StatusBadge status={status} />
                                </td>
                                <td className="px-4 py-3">
                                  {responseTime ? `${responseTime}ms` : 'N/A'}
                                </td>
                                <td className="px-4 py-3">
                                  {formatDate(lastChecked)}
                                </td>
                                <td className="px-4 py-3">
                                  {message}
                                </td>
                              </tr>
                            );
                          })
                        )}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="usage">
              <Card>
                <CardHeader>
                  <CardTitle>Integration Usage</CardTitle>
                  <CardDescription>
                    User adoption and transaction volume by integration
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-gray-800">
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Provider</th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Active Connections</th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Total Connections</th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Transaction Volume</th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Last Transaction</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-800">
                        {isLoadingIntegrations ? (
                          Array.from({ length: 6 }).map((_, i) => (
                            <tr key={`usage-skeleton-${i}`}>
                              <td className="px-4 py-3"><Skeleton className="h-4 w-32" /></td>
                              <td className="px-4 py-3"><Skeleton className="h-4 w-16" /></td>
                              <td className="px-4 py-3"><Skeleton className="h-4 w-16" /></td>
                              <td className="px-4 py-3"><Skeleton className="h-4 w-24" /></td>
                              <td className="px-4 py-3"><Skeleton className="h-4 w-32" /></td>
                            </tr>
                          ))
                        ) : (
                          integrations.map((integration: any) => {
                            // Simulate usage data
                            const activeConnections = Math.floor(Math.random() * 100) + 1;
                            const totalConnections = activeConnections + Math.floor(Math.random() * 50);
                            const transactionVolume = (Math.random() * 10000000).toLocaleString('en-IN', {
                              style: 'currency',
                              currency: 'INR',
                              maximumFractionDigits: 0
                            });
                            const lastTransaction = new Date(Date.now() - Math.random() * 86400000 * 7).toISOString();
                            
                            return (
                              <tr key={`usage-${integration.id}`} className="hover:bg-gray-800/50">
                                <td className="px-4 py-3">
                                  {integration.displayName}
                                </td>
                                <td className="px-4 py-3">
                                  {activeConnections}
                                </td>
                                <td className="px-4 py-3">
                                  {totalConnections}
                                </td>
                                <td className="px-4 py-3">
                                  {transactionVolume}
                                </td>
                                <td className="px-4 py-3">
                                  {formatDate(lastTransaction)}
                                </td>
                              </tr>
                            );
                          })
                        )}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        )}
      </div>
      
      {/* Status update dialog */}
      <Dialog 
        open={!!selectedIntegration} 
        onOpenChange={(open) => !open && setSelectedIntegration(null)}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Update Integration Status</DialogTitle>
            <DialogDescription>
              Change the status of {selectedIntegration?.displayName}. This will affect user access to this integration.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Current Status</label>
              <div className="flex items-center space-x-2">
                <StatusIcon status={selectedIntegration?.status} />
                <StatusBadge status={selectedIntegration?.status} />
              </div>
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">New Status</label>
              <Select value={newStatus} onValueChange={setNewStatus}>
                <SelectTrigger>
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="maintenance">Maintenance</SelectItem>
                  <SelectItem value="deprecated">Deprecated</SelectItem>
                  <SelectItem value="disabled">Disabled</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setSelectedIntegration(null)}
            >
              Cancel
            </Button>
            <Button 
              variant="default" 
              onClick={handleStatusUpdate}
              disabled={updateStatusMutation.isPending || newStatus === selectedIntegration?.status}
            >
              {updateStatusMutation.isPending ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Updating...
                </>
              ) : (
                'Update Status'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
}
