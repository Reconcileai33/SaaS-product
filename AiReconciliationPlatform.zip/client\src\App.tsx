
import { Route, Switch, useLocation } from "wouter";
import { ProtectedRoute, PublicOnlyRoute } from "@/lib/protected-route";
import { authApi } from "@/lib/api";
import AdminLayout from "@/components/layout/AdminLayout";

// Redirect component for wouter
const Redirect = ({ to }: { to: string }) => {
  const [, setLocation] = useLocation();
  setLocation(to);
  return null;
};
import Dashboard from "@/pages/dashboard";
import Transactions from "@/pages/transactions";
import Reconciliations from "@/pages/reconciliations";
import Integrations from "@/pages/integrations";
import Reports from "@/pages/reports";
import Beneficiaries from "@/pages/beneficiaries";
import Notifications from "@/pages/notifications";
import Settings from "@/pages/settings";
import Support from "@/pages/support";
import AuthPage from "@/pages/auth-page";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import Pricing from "@/pages/pricing";
import Features from "@/pages/features";
import About from "@/pages/about";
import Contact from "@/pages/contact";
import BankConnections from "@/pages/bank-connections";
import BankTransactions from "@/pages/bank-transactions";
import BankCallback from "@/pages/bank-callback";
import AdminDashboard from "@/pages/admin/dashboard";
import AdminAuditTrail from "@/pages/admin/audit-trail";
import AdminIntegrations from "@/pages/admin/integrations";
import AdminLogin from "@/pages/admin/login";
import AdminUsers from "@/pages/admin/users";
import AdminFeatures from "@/pages/admin/features";
import AdminSettings from "@/pages/admin/settings";
import ChatbotConnected from "@/components/support/ChatbotConnected";

function App() {
  const [location] = useLocation();
  
  return (
    <>
      <ChatbotConnected />
      <Switch>
        {/* Public pages that don't require authentication */}
        <Route path="/">
          <Home />
        </Route>
        <PublicOnlyRoute path="/auth">
          <AuthPage />
        </PublicOnlyRoute>
        <Route path="/pricing">
          <Pricing />
        </Route>
        <Route path="/features">
          <Features />
        </Route>
        <Route path="/about">
          <About />
        </Route>
        <Route path="/contact">
          <Contact />
        </Route>
        
        {/* Protected dashboard routes - require authentication */}
        <ProtectedRoute path="/dashboard">
          <Dashboard />
        </ProtectedRoute>
        <ProtectedRoute path="/transactions">
          <Transactions />
        </ProtectedRoute>
        <ProtectedRoute path="/reconciliations">
          <Reconciliations />
        </ProtectedRoute>
        <ProtectedRoute path="/reports">
          <Reports />
        </ProtectedRoute>
        <ProtectedRoute path="/integrations">
          <Integrations />
        </ProtectedRoute>
        <ProtectedRoute path="/beneficiaries">
          <Beneficiaries />
        </ProtectedRoute>
        <ProtectedRoute path="/notifications">
          <Notifications />
        </ProtectedRoute>
        <ProtectedRoute path="/settings">
          <Settings />
        </ProtectedRoute>
        <ProtectedRoute path="/support">
          <Support />
        </ProtectedRoute>
        
        {/* Bank integration routes */}
        <ProtectedRoute path="/bank-connections">
          <BankConnections />
        </ProtectedRoute>
        <ProtectedRoute path="/bank-transactions">
          <BankTransactions />
        </ProtectedRoute>
        <ProtectedRoute path="/bank-callback">
          <BankCallback />
        </ProtectedRoute>
        
        {/* Admin routes */}
        <Route path="/admin/login">
          <AdminLogin />
        </Route>
        <Route path="/admin">
          {authApi.isAdminAuthenticated() ? (
            <Route path="/admin/dashboard">
              <AdminLayout>
                <AdminDashboard />
              </AdminLayout>
            </Route>
          ) : (
            <Redirect to="/admin/login" />
          )}
        </Route>
        <Route path="/admin/audit-trail">
          {authApi.isAdminAuthenticated() ? (
            <AdminLayout>
              <AdminAuditTrail />
            </AdminLayout>
          ) : (
            <Redirect to="/admin/login" />
          )}
        </Route>
        <Route path="/admin/integrations">
          {authApi.isAdminAuthenticated() ? (
            <AdminLayout>
              <AdminIntegrations />
            </AdminLayout>
          ) : (
            <Redirect to="/admin/login" />
          )}
        </Route>
        <Route path="/admin/users">
          {authApi.isAdminAuthenticated() ? (
            <AdminLayout>
              <AdminUsers />
            </AdminLayout>
          ) : (
            <Redirect to="/admin/login" />
          )}
        </Route>
        <Route path="/admin/features">
          {authApi.isAdminAuthenticated() ? (
            <AdminLayout>
              <AdminFeatures />
            </AdminLayout>
          ) : (
            <Redirect to="/admin/login" />
          )}
        </Route>
        <Route path="/admin/settings">
          {authApi.isAdminAuthenticated() ? (
            <AdminLayout>
              <AdminSettings />
            </AdminLayout>
          ) : (
            <Redirect to="/admin/login" />
          )}
        </Route>
        
        {/* 404 page */}
        <Route>
          <NotFound />
        </Route>
      </Switch>
    </>
  );
}

export default App;
