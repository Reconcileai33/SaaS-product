import { ReactNode } from 'react';
import Header from './Header';
import Footer from './Footer';
import Chatbot from '../support/Chatbot';

interface MainLayoutProps {
  children: ReactNode;
}

export default function MainLayout({ children }: MainLayoutProps) {
  return (
    <div className="min-h-screen bg-black text-white">
      <Header />
      <main className="pt-20">
        {children}
      </main>
      <Footer />
      <Chatbot />
    </div>
  );
}
