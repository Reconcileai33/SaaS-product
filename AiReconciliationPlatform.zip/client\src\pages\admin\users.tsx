import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { Search, MoreVertical, UserPlus, Filter } from "lucide-react";
import { adminApi } from "@/lib/api";
import { pageContainerVariants } from "@/lib/animations";

// Mock user data - will be replaced with real API data
const mockUsers = [
  {
    id: "1",
    username: "johndoe",
    email: "john.doe@example.com",
    userType: "business",
    companyName: "Acme Corp",
    status: "active",
    lastLogin: "2025-05-10T10:30:00Z",
    createdAt: "2025-01-15T08:00:00Z"
  },
  {
    id: "2",
    username: "janedoe",
    email: "jane.doe@example.com",
    userType: "individual",
    companyName: null,
    status: "active",
    lastLogin: "2025-05-11T14:20:00Z",
    createdAt: "2025-02-20T09:30:00Z"
  },
  {
    id: "3",
    username: "bobsmith",
    email: "bob.smith@example.com",
    userType: "business",
    companyName: "Smith Enterprises",
    status: "inactive",
    lastLogin: "2025-04-30T16:45:00Z",
    createdAt: "2025-03-05T11:15:00Z"
  }
];

export default function AdminUsers() {
  const [users, setUsers] = useState(mockUsers);
  const [searchTerm, setSearchTerm] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  // In a real implementation, we would fetch users from the API
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        setIsLoading(true);
        // Uncomment when API is ready
        // const fetchedUsers = await adminApi.getUsers();
        // setUsers(fetchedUsers);
        
        // For now, simulate API call with a delay
        setTimeout(() => {
          setUsers(mockUsers);
          setIsLoading(false);
        }, 500);
      } catch (error) {
        console.error("Error fetching users:", error);
        setIsLoading(false);
      }
    };

    fetchUsers();
  }, []);

  // Filter users based on search term
  const filteredUsers = users.filter(user => 
    user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (user.companyName && user.companyName.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  // Format date for display
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  return (
    <motion.div
      className="space-y-6"
      variants={pageContainerVariants}
      initial="hidden"
      animate="visible"
    >
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">User Management</h1>
          <p className="text-slate-400">View and manage user accounts</p>
        </div>
        <Button className="btn-primary">
          <UserPlus size={16} className="mr-2" />
          Add User
        </Button>
      </div>

      <Card className="bg-slate-800 border-slate-700">
        <CardHeader className="pb-3">
          <CardTitle className="text-white">Users</CardTitle>
          <CardDescription>
            Total users: {users.length}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row justify-between gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400" size={18} />
              <Input
                placeholder="Search users..."
                className="pl-10 bg-slate-900 border-slate-700"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Button variant="outline" className="bg-slate-900 border-slate-700 text-slate-300">
              <Filter size={16} className="mr-2" />
              Filter
            </Button>
          </div>

          <div className="rounded-md border border-slate-700 overflow-hidden">
            <Table>
              <TableHeader className="bg-slate-900">
                <TableRow className="hover:bg-slate-800/50 border-slate-700">
                  <TableHead className="text-slate-300">Username</TableHead>
                  <TableHead className="text-slate-300">Email</TableHead>
                  <TableHead className="text-slate-300">Type</TableHead>
                  <TableHead className="text-slate-300">Status</TableHead>
                  <TableHead className="text-slate-300">Created</TableHead>
                  <TableHead className="text-slate-300">Last Login</TableHead>
                  <TableHead className="text-slate-300 text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-8 text-slate-400">
                      Loading users...
                    </TableCell>
                  </TableRow>
                ) : filteredUsers.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-8 text-slate-400">
                      No users found
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredUsers.map((user) => (
                    <TableRow key={user.id} className="hover:bg-slate-800/50 border-slate-700">
                      <TableCell className="font-medium text-white">{user.username}</TableCell>
                      <TableCell className="text-slate-300">{user.email}</TableCell>
                      <TableCell>
                        <Badge variant={user.userType === "business" ? "default" : "secondary"} className="capitalize">
                          {user.userType}
                          {user.companyName && ` - ${user.companyName}`}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant={user.status === "active" ? "success" : "destructive"} className="capitalize">
                          {user.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-slate-300">{formatDate(user.createdAt)}</TableCell>
                      <TableCell className="text-slate-300">{formatDate(user.lastLogin)}</TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                              <MoreVertical className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="bg-slate-900 border-slate-700">
                            <DropdownMenuItem className="text-white cursor-pointer hover:bg-slate-800">
                              Edit
                            </DropdownMenuItem>
                            <DropdownMenuItem className="text-white cursor-pointer hover:bg-slate-800">
                              View Details
                            </DropdownMenuItem>
                            <DropdownMenuItem className="text-white cursor-pointer hover:bg-slate-800">
                              Reset Password
                            </DropdownMenuItem>
                            <DropdownMenuItem className="text-red-500 cursor-pointer hover:bg-slate-800">
                              Deactivate
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
