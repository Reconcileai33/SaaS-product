import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Database, Plus, Save, Trash2, FileEdit, RefreshCw } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { schemaApi, SchemaTemplate, UserSchema, SchemaField } from "../../lib/schemaApi";

// Using the interfaces from schemaApi.ts

const SchemaManager = () => {
  const queryClient = useQueryClient();
  const [selectedTemplate, setSelectedTemplate] = useState<string>("");
  const [selectedSchema, setSelectedSchema] = useState<string>("");
  const [newSchemaName, setNewSchemaName] = useState("");
  const [newSchemaDescription, setNewSchemaDescription] = useState("");
  const [isCreatingSchema, setIsCreatingSchema] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // Fetch schema templates
  const { 
    data: templates = [], 
    isLoading: isTemplatesLoading,
    error: templatesError
  } = useQuery({
    queryKey: ['schemaTemplates'],
    queryFn: () => schemaApi.getSchemaTemplates()
  });

  // Fetch user schemas
  const {
    data: userSchemas = [],
    isLoading: isSchemasLoading,
    error: schemasError
  } = useQuery({
    queryKey: ['userSchemas'],
    queryFn: () => schemaApi.getUserSchemas()
  });

  // Create schema mutation
  const createSchemaMutation = useMutation({
    mutationFn: (data: { templateId: string, name: string, description: string }) => 
      schemaApi.createUserSchema(data.templateId, data.name, data.description),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['userSchemas'] });
      setSuccess("Schema created successfully!");
      setIsCreatingSchema(false);
      setNewSchemaName("");
      setNewSchemaDescription("");
      setSelectedTemplate("");
      
      // Clear success message after 3 seconds
      setTimeout(() => {
        setSuccess(null);
      }, 3000);
    },
    onError: (err: any) => {
      setError(err.message || "Failed to create schema");
      
      // Clear error message after 3 seconds
      setTimeout(() => {
        setError(null);
      }, 3000);
    }
  });

  // Delete schema mutation
  const deleteSchemaMutation = useMutation({
    mutationFn: (schemaId: string) => schemaApi.deleteUserSchema(schemaId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['userSchemas'] });
      setSuccess("Schema deleted successfully!");
      setSelectedSchema("");
      
      // Clear success message after 3 seconds
      setTimeout(() => {
        setSuccess(null);
      }, 3000);
    },
    onError: (err: any) => {
      setError(err.message || "Failed to delete schema");
      
      // Clear error message after 3 seconds
      setTimeout(() => {
        setError(null);
      }, 3000);
    }
  });

  // Toggle schema active status mutation
  const toggleSchemaActiveMutation = useMutation({
    mutationFn: ({ schemaId, isActive }: { schemaId: string, isActive: boolean }) => 
      schemaApi.updateUserSchema(schemaId, { isActive }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['userSchemas'] });
      setSuccess("Schema status updated successfully!");
      
      // Clear success message after 3 seconds
      setTimeout(() => {
        setSuccess(null);
      }, 3000);
    },
    onError: (err: any) => {
      setError(err.message || "Failed to update schema status");
      
      // Clear error message after 3 seconds
      setTimeout(() => {
        setError(null);
      }, 3000);
    }
  });

  // Handle create schema
  const handleCreateSchema = () => {
    if (!selectedTemplate) {
      setError("Please select a template");
      return;
    }

    if (!newSchemaName.trim()) {
      setError("Please enter a schema name");
      return;
    }

    createSchemaMutation.mutate({
      templateId: selectedTemplate,
      name: newSchemaName,
      description: newSchemaDescription
    });
  };

  // Handle delete schema
  const handleDeleteSchema = (schemaId: string) => {
    deleteSchemaMutation.mutate(schemaId);
  };

  // Handle toggle schema active status
  const handleToggleSchemaActive = (schemaId: string, currentStatus: boolean) => {
    toggleSchemaActiveMutation.mutate({ 
      schemaId, 
      isActive: !currentStatus 
    });
  };

  // Find selected schema details
  const selectedSchemaDetails = userSchemas.find((schema: UserSchema) => schema.id === selectedSchema);

  // Find selected template details
  const selectedTemplateDetails = templates.find((template: SchemaTemplate) => template.id === selectedTemplate);

  // Reset form when closing create dialog
  const handleCloseCreateDialog = (open: boolean) => {
    if (!open) {
      setNewSchemaName("");
      setNewSchemaDescription("");
      setSelectedTemplate("");
      setError(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Alerts */}
      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}
      
      {success && (
        <Alert className="bg-green-500/10 text-green-500 border-green-500/20">
          <AlertDescription>{success}</AlertDescription>
        </Alert>
      )}
      
      {/* Schema Management Tabs */}
      <Tabs defaultValue="mySchemas" className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="mySchemas">My Schemas</TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
        </TabsList>
        
        {/* My Schemas Tab */}
        <TabsContent value="mySchemas">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-medium">Your Custom Schemas</h3>
            <Dialog onOpenChange={handleCloseCreateDialog}>
              <DialogTrigger asChild>
                <Button 
                  className="bg-primary hover:bg-primary/90 text-white"
                  onClick={() => setIsCreatingSchema(true)}
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Create New Schema
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Create New Schema</DialogTitle>
                  <DialogDescription>
                    Create a custom schema based on a template
                  </DialogDescription>
                </DialogHeader>
                
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="template">Select Template</Label>
                    <Select 
                      value={selectedTemplate} 
                      onValueChange={setSelectedTemplate}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select a template" />
                      </SelectTrigger>
                      <SelectContent>
                        {templates.map((template: SchemaTemplate) => (
                          <SelectItem key={template.id} value={template.id}>
                            {template.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="schemaName">Schema Name</Label>
                    <Input 
                      id="schemaName" 
                      value={newSchemaName}
                      onChange={(e) => setNewSchemaName(e.target.value)}
                      placeholder="Enter schema name"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="schemaDescription">Description (Optional)</Label>
                    <Textarea 
                      id="schemaDescription" 
                      value={newSchemaDescription}
                      onChange={(e) => setNewSchemaDescription(e.target.value)}
                      placeholder="Enter schema description"
                      rows={3}
                    />
                  </div>
                  
                  {selectedTemplateDetails && (
                    <div className="space-y-2 border p-3 rounded-md bg-accent/20">
                      <h4 className="font-medium">Template Preview</h4>
                      <p className="text-sm text-muted-foreground">{selectedTemplateDetails.description}</p>
                      <div className="mt-2">
                        <p className="text-sm font-medium">Fields:</p>
                        <div className="flex flex-wrap gap-2 mt-1">
                          {selectedTemplateDetails.fields.map((field: SchemaField, index: number) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {field.name} ({field.type})
                              {field.isRequired && "*"}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
                
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsCreatingSchema(false)}>
                    Cancel
                  </Button>
                  <Button 
                    className="bg-primary hover:bg-primary/90 text-white"
                    onClick={handleCreateSchema}
                    disabled={createSchemaMutation.isPending}
                  >
                    {createSchemaMutation.isPending && (
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                    )}
                    Create Schema
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
          
          {isSchemasLoading ? (
            <div className="flex justify-center items-center py-8">
              <RefreshCw className="h-6 w-6 animate-spin text-primary" />
            </div>
          ) : userSchemas.length === 0 ? (
            <Card>
              <CardContent className="py-8 text-center">
                <Database className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-lg font-medium mb-2">No Schemas Found</h3>
                <p className="text-muted-foreground mb-4">
                  You haven't created any custom schemas yet.
                </p>
                <Dialog onOpenChange={handleCloseCreateDialog}>
                  <DialogTrigger asChild>
                    <Button 
                      className="bg-primary hover:bg-primary/90 text-white"
                      onClick={() => setIsCreatingSchema(true)}
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Create Your First Schema
                    </Button>
                  </DialogTrigger>
                  {/* Dialog content is the same as above */}
                </Dialog>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {userSchemas.map((schema: UserSchema) => (
                <Card key={schema.id} className={`border ${schema.isActive ? 'border-primary/30' : 'border-muted'}`}>
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-base">{schema.name}</CardTitle>
                        <CardDescription className="text-xs">
                          Collection: {schema.collectionName}
                        </CardDescription>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch 
                          checked={schema.isActive}
                          onCheckedChange={() => handleToggleSchemaActive(schema.id, schema.isActive)}
                        />
                        <Badge variant={schema.isActive ? "default" : "outline"} className="text-xs">
                          {schema.isActive ? 'Active' : 'Inactive'}
                        </Badge>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground mb-3">
                      {schema.description || 'No description provided'}
                    </p>
                    
                    <div className="mb-3">
                      <p className="text-xs font-medium mb-1">Fields:</p>
                      <div className="flex flex-wrap gap-1">
                        {schema.fields.slice(0, 5).map((field: SchemaField, index: number) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {field.name}
                          </Badge>
                        ))}
                        {schema.fields.length > 5 && (
                          <Badge variant="outline" className="text-xs">
                            +{schema.fields.length - 5} more
                          </Badge>
                        )}
                      </div>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-muted-foreground">
                        Created: {new Date(schema.createdAt).toLocaleDateString()}
                      </span>
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm" className="h-8 px-2">
                          <FileEdit className="h-3.5 w-3.5" />
                        </Button>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="h-8 px-2 text-red-500 hover:text-red-700"
                          onClick={() => handleDeleteSchema(schema.id)}
                          disabled={deleteSchemaMutation.isPending}
                        >
                          {deleteSchemaMutation.isPending && deleteSchemaMutation.variables === schema.id ? (
                            <RefreshCw className="h-3.5 w-3.5 animate-spin" />
                          ) : (
                            <Trash2 className="h-3.5 w-3.5" />
                          )}
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
        
        {/* Templates Tab */}
        <TabsContent value="templates">
          <h3 className="text-lg font-medium mb-4">Available Schema Templates</h3>
          
          {isTemplatesLoading ? (
            <div className="flex justify-center items-center py-8">
              <RefreshCw className="h-6 w-6 animate-spin text-primary" />
            </div>
          ) : templates.length === 0 ? (
            <Card>
              <CardContent className="py-8 text-center">
                <Database className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-lg font-medium mb-2">No Templates Available</h3>
                <p className="text-muted-foreground">
                  No schema templates are currently available.
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {templates.map((template: SchemaTemplate) => (
                <Card key={template.id}>
                  <CardHeader>
                    <CardTitle className="text-base">{template.name}</CardTitle>
                    <CardDescription>
                      {template.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="mb-4">
                      <p className="text-xs font-medium mb-1">Fields:</p>
                      <div className="flex flex-wrap gap-1">
                        {template.fields.map((field: SchemaField, index: number) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {field.name} ({field.type})
                            {field.isRequired && "*"}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    
                    <Dialog onOpenChange={handleCloseCreateDialog}>
                      <DialogTrigger asChild>
                        <Button 
                          className="w-full bg-primary hover:bg-primary/90 text-white"
                          onClick={() => setSelectedTemplate(template.id)}
                        >
                          Use This Template
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Create Schema from Template</DialogTitle>
                          <DialogDescription>
                            Create a custom schema based on the {template.name} template
                          </DialogDescription>
                        </DialogHeader>
                        
                        <div className="space-y-4 py-4">
                          <div className="space-y-2">
                            <Label htmlFor="schemaName">Schema Name</Label>
                            <Input 
                              id="schemaName" 
                              value={newSchemaName}
                              onChange={(e) => setNewSchemaName(e.target.value)}
                              placeholder="Enter schema name"
                            />
                          </div>
                          
                          <div className="space-y-2">
                            <Label htmlFor="schemaDescription">Description (Optional)</Label>
                            <Textarea 
                              id="schemaDescription" 
                              value={newSchemaDescription}
                              onChange={(e) => setNewSchemaDescription(e.target.value)}
                              placeholder="Enter schema description"
                              rows={3}
                            />
                          </div>
                        </div>
                        
                        <DialogFooter>
                          <Button variant="outline" onClick={() => setIsCreatingSchema(false)}>
                            Cancel
                          </Button>
                          <Button 
                            className="bg-primary hover:bg-primary/90 text-white"
                            onClick={handleCreateSchema}
                            disabled={createSchemaMutation.isPending}
                          >
                            {createSchemaMutation.isPending && (
                              <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                            )}
                            Create Schema
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default SchemaManager;
