import React, { useState, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { api } from '../../lib/api';

// Inline styles
const styles = {
  container: { margin: '0 0 2rem 0' },
  header: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' },
  heading: { fontSize: '1.5rem', fontWeight: 'bold', margin: '0' },
  button: { padding: '0.5rem 1rem', backgroundColor: '#1976d2', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' },
  buttonDisabled: { padding: '0.5rem 1rem', backgroundColor: '#ccc', color: 'white', border: 'none', borderRadius: '4px', cursor: 'not-allowed' },
  loadingContainer: { display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '300px' },
  spinner: { border: '4px solid #f3f3f3', borderTop: '4px solid #3498db', borderRadius: '50%', width: '30px', height: '30px', animation: 'spin 2s linear infinite' },
  errorText: { color: 'red', textAlign: 'center' as const },
  grid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(250px, 1fr))', gap: '1rem', marginBottom: '1rem' },
  card: { padding: '1rem', border: '1px solid #ddd', borderRadius: '4px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)' },
  cardLabel: { color: '#666', marginBottom: '0.5rem', fontSize: '0.9rem' },
  cardValue: { fontSize: '1.5rem', fontWeight: 'bold', margin: '0' },
  cardValueSuccess: { fontSize: '1.5rem', fontWeight: 'bold', margin: '0', color: 'green' },
  cardValueError: { fontSize: '1.5rem', fontWeight: 'bold', margin: '0', color: 'red' },
  chartContainer: { height: '300px', marginTop: '1rem' },
  chartCard: { padding: '1rem', border: '1px solid #ddd', borderRadius: '4px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)', marginBottom: '1rem' },
  chartTitle: { fontSize: '1.2rem', fontWeight: 'bold', marginBottom: '0.5rem' }
};

interface TransactionAnalyticsProps {
  connectionId: string;
}

interface AnalyticsData {
  totalTransactions: number;
  totalCredits: number;
  totalDebits: number;
  netBalance: number;
  averageTransactionAmount: number;
  categories: Record<string, number>;
  dailyVolume: {
    date: string;
    volume: number;
    count: number;
  }[];
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8', '#82CA9D', '#A4DE6C'];

const TransactionAnalytics: React.FC<TransactionAnalyticsProps> = ({ connectionId }) => {
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [analytics, setAnalytics] = useState<AnalyticsData | null>(null);
  const [syncLoading, setSyncLoading] = useState<boolean>(false);

  const fetchAnalytics = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await api.bankIntegrations.getTransactionAnalytics(connectionId);
      setAnalytics(response);
    } catch (err) {
      setError('Failed to load transaction analytics. Please try again later.');
      console.error('Error fetching transaction analytics:', err);
    } finally {
      setLoading(false);
    }
  };

  const syncTransactions = async () => {
    setSyncLoading(true);
    
    try {
      await api.bankIntegrations.syncTransactions(connectionId);
      // Refresh analytics after sync
      fetchAnalytics();
    } catch (err) {
      setError('Failed to synchronize transactions. Please try again later.');
      console.error('Error syncing transactions:', err);
    } finally {
      setSyncLoading(false);
    }
  };

  useEffect(() => {
    if (connectionId) {
      fetchAnalytics();
    }
  }, [connectionId]);

  if (loading) {
    return (
      <div style={styles.loadingContainer}>
        <div style={styles.spinner}></div>
      </div>
    );
  }

  if (error) {
    return (
      <div style={styles.loadingContainer}>
        <p style={styles.errorText}>{error}</p>
      </div>
    );
  }

  if (!analytics) {
    return (
      <div style={styles.loadingContainer}>
        <p>No analytics data available</p>
      </div>
    );
  }

  // Convert categories object to array for pie chart
  const categoryData = Object.entries(analytics.categories || {}).map(([name, value]) => ({
    name,
    value
  }));

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <h2 style={styles.heading}>Transaction Analytics</h2>
        <button 
          style={syncLoading ? styles.buttonDisabled : styles.button} 
          onClick={syncTransactions} 
          disabled={syncLoading}
        >
          {syncLoading ? 'Syncing...' : 'Sync Transactions'}
        </button>
      </div>

      <div style={styles.grid}>
        {/* Summary Cards */}
        <div style={styles.card}>
          <div style={styles.cardLabel}>Total Transactions</div>
          <p style={styles.cardValue}>{analytics.totalTransactions}</p>
        </div>
        
        <div style={styles.card}>
          <div style={styles.cardLabel}>Total Credits</div>
          <p style={styles.cardValueSuccess}>₹{analytics.totalCredits.toLocaleString()}</p>
        </div>
        
        <div style={styles.card}>
          <div style={styles.cardLabel}>Total Debits</div>
          <p style={styles.cardValueError}>₹{analytics.totalDebits.toLocaleString()}</p>
        </div>
        
        <div style={styles.card}>
          <div style={styles.cardLabel}>Net Balance</div>
          <p style={analytics.netBalance >= 0 ? styles.cardValueSuccess : styles.cardValueError}>
            ₹{analytics.netBalance.toLocaleString()}
          </p>
        </div>
      </div>

      {/* Charts */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
        <div style={styles.chartCard}>
          <h3 style={styles.chartTitle}>Daily Transaction Volume</h3>
          <div style={styles.chartContainer}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={analytics.dailyVolume}
                margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="volume" name="Volume (₹)" fill="#8884d8" />
                <Bar dataKey="count" name="Count" fill="#82ca9d" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div style={styles.chartCard}>
          <h3 style={styles.chartTitle}>Transaction Categories</h3>
          <div style={styles.chartContainer}>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TransactionAnalytics;
