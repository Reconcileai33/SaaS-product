/**
 * Bank Connections Page
 * 
 * This page allows users to manage their bank connections.
 */

import React, { useState } from "react";
import { motion } from "framer-motion";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { pageContainerVariants, pageItemVariants } from "@/lib/animations";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { 
  AlertCircle, 
  Building as Bank, 
  CheckCircle, 
  ChevronRight, 
  Clock, 
  CreditCard, 
  ExternalLink, 
  Link as LinkIcon, 
  Link2Off as LinkOff, 
  Plus, 
  RefreshCw, 
  Shield, 
  Wallet 
} from "lucide-react";
import { bankIntegrationApi, BankConnection, BankIntegration, SSOProvider } from "@/lib/bankIntegrationApi";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
// Import toast functionality
import { toast } from "@/components/ui/use-toast";

// Create a hook-like interface for toast
const useToast = () => ({ toast });

// Connection status badge
const ConnectionStatusBadge = ({ status }: { status: string }) => {
  switch (status) {
    case 'active':
      return <Badge className="ml-2 bg-green-500 hover:bg-green-600">Active</Badge>;
    case 'expired':
      return <Badge className="ml-2 bg-amber-500 hover:bg-amber-600">Expired</Badge>;
    case 'revoked':
      return <Badge variant="destructive" className="ml-2">Revoked</Badge>;
    case 'error':
      return <Badge variant="destructive" className="ml-2">Error</Badge>;
    default:
      return <Badge variant="outline" className="ml-2">{status}</Badge>;
  }
};

// Integration status badge
const IntegrationStatusBadge = ({ status }: { status: string }) => {
  switch (status) {
    case 'active':
      return <Badge className="ml-2 bg-green-500 hover:bg-green-600">Active</Badge>;
    case 'maintenance':
      return <Badge className="ml-2 bg-amber-500 hover:bg-amber-600">Maintenance</Badge>;
    case 'deprecated':
      return <Badge variant="secondary" className="ml-2">Deprecated</Badge>;
    case 'disabled':
      return <Badge variant="destructive" className="ml-2">Disabled</Badge>;
    default:
      return <Badge variant="outline" className="ml-2">{status}</Badge>;
  }
};

// Format date
const formatDate = (dateString: string) => {
  const date = new Date(dateString);
  return new Intl.DateTimeFormat('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    hour12: true
  }).format(date);
};

// Connection card component
const ConnectionCard = ({ 
  connection, 
  onRefresh, 
  onDisconnect 
}: { 
  connection: BankConnection; 
  onRefresh: (id: string) => void;
  onDisconnect: (id: string) => void;
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  
  // Check if connection is expired
  const isExpired = new Date(connection.expiresAt) < new Date();
  
  return (
    <Card className="overflow-hidden transition-all duration-200">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <Bank className="h-5 w-5 mr-2 text-primary" />
            <CardTitle className="text-lg">{connection.accountName}</CardTitle>
            <ConnectionStatusBadge status={connection.status} />
          </div>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => setIsExpanded(!isExpanded)}
          >
            <ChevronRight className={`h-4 w-4 transition-transform ${isExpanded ? 'rotate-90' : ''}`} />
          </Button>
        </div>
        <CardDescription>
          {connection.provider.toUpperCase()} • {connection.accountType} • {connection.accountId}
        </CardDescription>
      </CardHeader>
      
      {isExpanded && (
        <CardContent className="pb-2 pt-0">
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Status:</span>
              <span className="font-medium">{connection.status}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Connected on:</span>
              <span className="font-medium">{formatDate(connection.createdAt)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Last refreshed:</span>
              <span className="font-medium">{formatDate(connection.lastRefreshed)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Expires at:</span>
              <span className={`font-medium ${isExpired ? 'text-destructive' : ''}`}>
                {formatDate(connection.expiresAt)}
                {isExpired && <Clock className="inline ml-1 h-3 w-3" />}
              </span>
            </div>
          </div>
        </CardContent>
      )}
      
      <CardFooter className="pt-2">
        <div className="flex space-x-2 w-full">
          <Button 
            variant="outline" 
            size="sm" 
            className="flex-1"
            onClick={() => onRefresh(connection.id)}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          <Button 
            variant="destructive" 
            size="sm" 
            className="flex-1"
            onClick={() => onDisconnect(connection.id)}
          >
            <LinkOff className="h-4 w-4 mr-2" />
            Disconnect
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
};

// Integration card component
const IntegrationCard = ({ 
  integration, 
  onConnect 
}: { 
  integration: BankIntegration; 
  onConnect: (provider: SSOProvider) => void;
}) => {
  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle>{integration.displayName}</CardTitle>
          <IntegrationStatusBadge status={integration.status} />
        </div>
        <CardDescription>{integration.description}</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          <div className="flex flex-wrap gap-2">
            {integration.features.accountInfo && (
              <Badge variant="outline">Account Info</Badge>
            )}
            {integration.features.transactions && (
              <Badge variant="outline">Transactions</Badge>
            )}
            {integration.features.payments && (
              <Badge variant="outline">Payments</Badge>
            )}
            {integration.features.beneficiaries && (
              <Badge variant="outline">Beneficiaries</Badge>
            )}
            {integration.features.statements && (
              <Badge variant="outline">Statements</Badge>
            )}
          </div>
        </div>
      </CardContent>
      <CardFooter>
        <div className="flex space-x-2 w-full">
          <Button 
            variant="default" 
            className="flex-1"
            disabled={integration.status !== 'active'}
            onClick={() => onConnect(integration.provider)}
          >
            <LinkIcon className="h-4 w-4 mr-2" />
            Connect
          </Button>
          <Button 
            variant="outline" 
            size="icon"
            asChild
          >
            <a href={integration.documentationUrl} target="_blank" rel="noopener noreferrer">
              <ExternalLink className="h-4 w-4" />
            </a>
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
};

export default function BankConnectionsPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("connections");
  const [confirmDisconnect, setConfirmDisconnect] = useState<string | null>(null);
  
  // Fetch user connections
  const { 
    data: connections = [], 
    isLoading: isLoadingConnections,
    error: connectionsError
  } = useQuery({
    queryKey: ['bankConnections'],
    queryFn: () => bankIntegrationApi.getUserConnections()
  });
  
  // Fetch available integrations
  const { 
    data: integrations = [], 
    isLoading: isLoadingIntegrations,
    error: integrationsError
  } = useQuery({
    queryKey: ['bankIntegrations'],
    queryFn: () => bankIntegrationApi.getIntegrations()
  });
  
  // Initiate connection mutation
  const initiateMutation = useMutation({
    mutationFn: (provider: SSOProvider) => bankIntegrationApi.initiateConnection(provider),
    onSuccess: (data) => {
      // Redirect to the bank's SSO page
      window.location.href = data.redirectUrl;
    },
    onError: (error: any) => {
      toast({
        title: "Connection Failed",
        description: error.message || "Failed to initiate bank connection",
        variant: "destructive"
      });
    }
  });
  
  // Refresh connection mutation
  const refreshMutation = useMutation({
    mutationFn: (connectionId: string) => bankIntegrationApi.refreshConnection(connectionId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['bankConnections'] });
      toast({
        title: "Connection Refreshed",
        description: "Your bank connection has been successfully refreshed",
        variant: "default"
      });
    },
    onError: (error: any) => {
      toast({
        title: "Refresh Failed",
        description: error.message || "Failed to refresh bank connection",
        variant: "destructive"
      });
    }
  });
  
  // Disconnect mutation
  const disconnectMutation = useMutation({
    mutationFn: (connectionId: string) => bankIntegrationApi.disconnectConnection(connectionId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['bankConnections'] });
      toast({
        title: "Connection Removed",
        description: "Your bank connection has been successfully removed",
        variant: "default"
      });
      setConfirmDisconnect(null);
    },
    onError: (error: any) => {
      toast({
        title: "Disconnection Failed",
        description: error.message || "Failed to remove bank connection",
        variant: "destructive"
      });
    }
  });
  
  // Handle connect
  const handleConnect = (provider: SSOProvider) => {
    initiateMutation.mutate(provider);
  };
  
  // Handle refresh
  const handleRefresh = (connectionId: string) => {
    refreshMutation.mutate(connectionId);
  };
  
  // Handle disconnect
  const handleDisconnect = (connectionId: string) => {
    setConfirmDisconnect(connectionId);
  };
  
  // Confirm disconnect
  const confirmDisconnectHandler = () => {
    if (confirmDisconnect) {
      disconnectMutation.mutate(confirmDisconnect);
    }
  };
  
  // Loading states
  const isLoading = isLoadingConnections || isLoadingIntegrations;
  const isError = !!connectionsError || !!integrationsError;
  
  // Filter active integrations
  const activeIntegrations = integrations.filter(i => i.status === 'active');
  
  return (
    <>
      <Header />
      
      <motion.main 
        className="flex-1"
        initial="initial"
        animate="animate"
        exit="exit"
        variants={pageContainerVariants}
      >
        <div className="container mx-auto px-4 py-12">
          <motion.div 
            className="mb-8"
            variants={pageItemVariants}
          >
            <h1 className="text-3xl font-bold mb-2">Bank Connections</h1>
            <p className="text-gray-400">
              Connect your bank accounts to automate reconciliation and financial management
            </p>
          </motion.div>
          
          <motion.div variants={pageItemVariants}>
            <Tabs 
              defaultValue="connections" 
              value={activeTab}
              onValueChange={setActiveTab}
              className="w-full"
            >
              <TabsList className="mb-6">
                <TabsTrigger value="connections">
                  <CreditCard className="h-4 w-4 mr-2" />
                  My Connections
                </TabsTrigger>
                <TabsTrigger value="available">
                  <Bank className="h-4 w-4 mr-2" />
                  Available Banks
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="connections" className="space-y-6">
                {isLoading ? (
                  // Loading skeleton
                  Array.from({ length: 3 }).map((_, i) => (
                    <Card key={`skeleton-${i}`}>
                      <CardHeader>
                        <Skeleton className="h-6 w-48" />
                        <Skeleton className="h-4 w-72 mt-2" />
                      </CardHeader>
                      <CardContent>
                        <Skeleton className="h-20 w-full" />
                      </CardContent>
                      <CardFooter>
                        <Skeleton className="h-10 w-full" />
                      </CardFooter>
                    </Card>
                  ))
                ) : isError ? (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>Error</AlertTitle>
                    <AlertDescription>
                      Failed to load bank connections. Please try again later.
                    </AlertDescription>
                  </Alert>
                ) : connections.length === 0 ? (
                  <div className="text-center py-12">
                    <Wallet className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                    <h3 className="text-xl font-medium mb-2">No Bank Connections</h3>
                    <p className="text-gray-400 mb-6">
                      You haven't connected any bank accounts yet
                    </p>
                    <Button onClick={() => setActiveTab("available")}>
                      <Plus className="h-4 w-4 mr-2" />
                      Connect a Bank
                    </Button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {connections.map((connection) => (
                      <ConnectionCard 
                        key={connection.id}
                        connection={connection}
                        onRefresh={handleRefresh}
                        onDisconnect={handleDisconnect}
                      />
                    ))}
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="available" className="space-y-6">
                {isLoading ? (
                  // Loading skeleton
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {Array.from({ length: 6 }).map((_, i) => (
                      <Card key={`skeleton-${i}`}>
                        <CardHeader>
                          <Skeleton className="h-6 w-48" />
                          <Skeleton className="h-4 w-72 mt-2" />
                        </CardHeader>
                        <CardContent>
                          <Skeleton className="h-12 w-full" />
                        </CardContent>
                        <CardFooter>
                          <Skeleton className="h-10 w-full" />
                        </CardFooter>
                      </Card>
                    ))}
                  </div>
                ) : isError ? (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>Error</AlertTitle>
                    <AlertDescription>
                      Failed to load available banks. Please try again later.
                    </AlertDescription>
                  </Alert>
                ) : (
                  <>
                    {activeIntegrations.length > 0 && (
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        {activeIntegrations.map((integration) => (
                          <IntegrationCard 
                            key={integration.id}
                            integration={integration}
                            onConnect={handleConnect}
                          />
                        ))}
                      </div>
                    )}
                    
                    {integrations.filter(i => i.status !== 'active').length > 0 && (
                      <div className="mt-8">
                        <h3 className="text-lg font-medium mb-4">Coming Soon</h3>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 opacity-70">
                          {integrations
                            .filter(i => i.status !== 'active')
                            .map((integration) => (
                              <IntegrationCard 
                                key={integration.id}
                                integration={integration}
                                onConnect={handleConnect}
                              />
                            ))}
                        </div>
                      </div>
                    )}
                    
                    <div className="bg-gray-900/50 backdrop-blur-sm border border-gray-800 rounded-lg p-6 mt-8">
                      <div className="flex items-start space-x-4">
                        <Shield className="h-8 w-8 text-primary mt-1" />
                        <div>
                          <h3 className="text-lg font-medium mb-2">Secure Bank Connections</h3>
                          <p className="text-gray-400 mb-2">
                            We use industry-standard encryption and security practices to ensure your banking information is protected:
                          </p>
                          <ul className="list-disc list-inside text-gray-400 space-y-1">
                            <li>We never store your bank credentials</li>
                            <li>All data is encrypted in transit and at rest</li>
                            <li>We use OAuth and token-based authentication</li>
                            <li>You can revoke access at any time</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </>
                )}
              </TabsContent>
            </Tabs>
          </motion.div>
        </div>
      </motion.main>
      
      {/* Disconnect confirmation dialog */}
      <Dialog 
        open={!!confirmDisconnect} 
        onOpenChange={(open) => !open && setConfirmDisconnect(null)}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Disconnect Bank Account</DialogTitle>
            <DialogDescription>
              Are you sure you want to disconnect this bank account? This will remove all access to your account data.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setConfirmDisconnect(null)}
            >
              Cancel
            </Button>
            <Button 
              variant="destructive" 
              onClick={confirmDisconnectHandler}
              disabled={disconnectMutation.isPending}
            >
              {disconnectMutation.isPending ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  Disconnecting...
                </>
              ) : (
                <>
                  <LinkOff className="h-4 w-4 mr-2" />
                  Disconnect
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      <Footer />
    </>
  );
}
