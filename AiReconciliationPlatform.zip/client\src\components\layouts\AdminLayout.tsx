/**
 * Admin Layout Component
 * 
 * This component provides a consistent layout for admin pages.
 */

import React, { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { 
  BarChart3, 
  Users, 
  Settings, 
  LogOut, 
  AlertCircle, 
  Database, 
  Flag, 
  CreditCard, 
  Building, 
  Home 
} from "lucide-react";
import { authApi } from "@/lib/api";
import { Button } from "@/components/ui/button";

interface AdminLayoutProps {
  children: ReactNode;
}

export function AdminLayout({ children }: AdminLayoutProps) {
  const [location, setLocation] = useLocation();
  
  // Handle logout
  const handleLogout = () => {
    authApi.adminLogout();
    setLocation('/admin/login');
  };
  
  // Navigation items
  const navItems = [
    { 
      name: 'Dashboard', 
      path: '/admin/dashboard', 
      icon: <BarChart3 className="h-5 w-5" /> 
    },
    { 
      name: 'Users', 
      path: '/admin/users', 
      icon: <Users className="h-5 w-5" /> 
    },
    { 
      name: 'Transactions', 
      path: '/admin/transactions', 
      icon: <CreditCard className="h-5 w-5" /> 
    },
    { 
      name: 'Organizations', 
      path: '/admin/organizations', 
      icon: <Building className="h-5 w-5" /> 
    },
    { 
      name: 'Audit Trail', 
      path: '/admin/audit-trail', 
      icon: <AlertCircle className="h-5 w-5" /> 
    },
    { 
      name: 'Feature Flags', 
      path: '/admin/feature-flags', 
      icon: <Flag className="h-5 w-5" /> 
    },
    { 
      name: 'Integrations', 
      path: '/admin/integrations', 
      icon: <Database className="h-5 w-5" /> 
    },
    { 
      name: 'Settings', 
      path: '/admin/settings', 
      icon: <Settings className="h-5 w-5" /> 
    }
  ];
  
  return (
    <div className="flex h-screen bg-gray-950 text-white">
      {/* Sidebar */}
      <div className="w-64 bg-gray-900 border-r border-gray-800 flex flex-col">
        {/* Logo */}
        <div className="p-4 border-b border-gray-800">
          <h1 className="text-xl font-bold bg-gradient-to-r from-purple-500 via-pink-500 to-red-500 bg-clip-text text-transparent">
            Reconcile AI Admin
          </h1>
        </div>
        
        {/* Navigation */}
        <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
          {navItems.map((item) => (
            <Link key={item.path} href={item.path}>
              <a className={`flex items-center space-x-3 px-3 py-2 rounded-md transition-colors ${
                location === item.path 
                  ? 'bg-gray-800 text-white' 
                  : 'text-gray-400 hover:text-white hover:bg-gray-800/50'
              }`}>
                {item.icon}
                <span>{item.name}</span>
              </a>
            </Link>
          ))}
        </nav>
        
        {/* Bottom actions */}
        <div className="p-4 border-t border-gray-800 space-y-2">
          <Link href="/">
            <a className="flex items-center space-x-3 px-3 py-2 rounded-md text-gray-400 hover:text-white hover:bg-gray-800/50 transition-colors">
              <Home className="h-5 w-5" />
              <span>Back to App</span>
            </a>
          </Link>
          
          <Button 
            variant="ghost" 
            className="w-full justify-start text-red-400 hover:text-red-300 hover:bg-red-900/20"
            onClick={handleLogout}
          >
            <LogOut className="h-5 w-5 mr-3" />
            Logout
          </Button>
        </div>
      </div>
      
      {/* Main content */}
      <div className="flex-1 overflow-y-auto bg-gradient-to-br from-gray-900 to-gray-950">
        {children}
      </div>
    </div>
  );
}
