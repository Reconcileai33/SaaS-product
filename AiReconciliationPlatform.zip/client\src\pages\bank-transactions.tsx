/**
 * Bank Transactions Page
 * 
 * This page displays bank transactions from connected accounts.
 */

import React, { useState } from "react";
import { motion } from "framer-motion";
import { useQuery } from "@tanstack/react-query";
import { pageContainerVariants, pageItemVariants } from "@/lib/animations";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  AlertCircle, 
  ArrowDownUp, 
  Calendar, 
  CreditCard, 
  Download, 
  Filter, 
  RefreshCw, 
  Search, 
  Building as Bank
} from "lucide-react";
import { bankIntegrationApi, BankConnection } from "@/lib/bankIntegrationApi";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";

// Transaction type
interface Transaction {
  id: string;
  connectionId: string;
  accountId: string;
  amount: number;
  currency: string;
  description: string;
  category?: string;
  reference?: string;
  date: string;
  status: 'pending' | 'completed' | 'failed';
  type: 'credit' | 'debit';
  metadata?: Record<string, any>;
}

// Format currency
const formatCurrency = (amount: number, currency: string = 'INR') => {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency,
    minimumFractionDigits: 2
  }).format(amount);
};

// Transaction card component
const TransactionCard = ({ transaction }: { transaction: Transaction }) => {
  const isCredit = transaction.type === 'credit';
  
  return (
    <Card className="overflow-hidden hover:bg-gray-900/50 transition-colors">
      <CardContent className="p-4">
        <div className="flex justify-between items-center">
          <div className="flex items-start space-x-4">
            <div className={`p-2 rounded-full ${isCredit ? 'bg-green-500/20' : 'bg-red-500/20'}`}>
              <ArrowDownUp className={`h-5 w-5 ${isCredit ? 'text-green-500' : 'text-red-500'} ${isCredit ? 'rotate-180' : ''}`} />
            </div>
            <div>
              <div className="font-medium">{transaction.description}</div>
              <div className="text-sm text-gray-400">
                {transaction.reference ? `Ref: ${transaction.reference}` : 'No reference'}
                {transaction.category && (
                  <Badge variant="outline" className="ml-2">{transaction.category}</Badge>
                )}
              </div>
            </div>
          </div>
          <div className="text-right">
            <div className={`font-medium ${isCredit ? 'text-green-500' : 'text-red-500'}`}>
              {isCredit ? '+' : '-'} {formatCurrency(Math.abs(transaction.amount), transaction.currency)}
            </div>
            <div className="text-sm text-gray-400">
              {format(new Date(transaction.date), 'dd MMM yyyy')}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default function BankTransactionsPage() {
  const [selectedConnection, setSelectedConnection] = useState<string>("");
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [dateRange, setDateRange] = useState<{ startDate?: string; endDate?: string }>({});
  const [transactionType, setTransactionType] = useState<string>("");
  
  // Fetch user's bank connections
  const { 
    data: connections = [], 
    isLoading: isLoadingConnections,
    error: connectionsError
  } = useQuery({
    queryKey: ['bankConnections'],
    queryFn: () => bankIntegrationApi.getUserConnections()
  });
  
  // Fetch transactions for selected connection
  const { 
    data: transactions = [], 
    isLoading: isLoadingTransactions,
    error: transactionsError,
    refetch: refetchTransactions
  } = useQuery({
    queryKey: ['bankTransactions', selectedConnection, dateRange],
    queryFn: () => bankIntegrationApi.getConnectionTransactions(
      selectedConnection, 
      {
        startDate: dateRange.startDate,
        endDate: dateRange.endDate,
        limit: 50
      }
    ),
    enabled: !!selectedConnection
  });
  
  // Filter transactions based on search term and type
  const filteredTransactions = transactions.filter((transaction: Transaction) => {
    const matchesSearch = searchTerm 
      ? transaction.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (transaction.reference?.toLowerCase().includes(searchTerm.toLowerCase()) ?? false)
      : true;
      
    const matchesType = transactionType 
      ? transaction.type === transactionType 
      : true;
      
    return matchesSearch && matchesType;
  });
  
  // Handle date range change
  const handleDateRangeChange = (range: 'today' | 'week' | 'month' | 'quarter' | 'year' | 'custom') => {
    const today = new Date();
    let startDate: Date | undefined;
    
    switch (range) {
      case 'today':
        startDate = today;
        break;
      case 'week':
        startDate = new Date(today);
        startDate.setDate(today.getDate() - 7);
        break;
      case 'month':
        startDate = new Date(today);
        startDate.setMonth(today.getMonth() - 1);
        break;
      case 'quarter':
        startDate = new Date(today);
        startDate.setMonth(today.getMonth() - 3);
        break;
      case 'year':
        startDate = new Date(today);
        startDate.setFullYear(today.getFullYear() - 1);
        break;
      case 'custom':
        // Handle custom date range in a real implementation
        return;
    }
    
    setDateRange({
      startDate: startDate?.toISOString(),
      endDate: today.toISOString()
    });
  };
  
  // Export transactions as CSV
  const exportTransactions = () => {
    if (!filteredTransactions.length) return;
    
    const headers = ['Date', 'Description', 'Reference', 'Category', 'Amount', 'Currency', 'Type', 'Status'];
    const csvRows = [
      headers.join(','),
      ...filteredTransactions.map((t: Transaction) => [
        format(new Date(t.date), 'yyyy-MM-dd'),
        `"${t.description.replace(/"/g, '""')}"`,
        `"${t.reference?.replace(/"/g, '""') || ''}"`,
        `"${t.category || ''}"`,
        Math.abs(t.amount),
        t.currency,
        t.type,
        t.status
      ].join(','))
    ];
    
    const csvContent = csvRows.join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `transactions-${format(new Date(), 'yyyy-MM-dd')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  
  // Calculate total amounts
  const totals = filteredTransactions.reduce((acc: { credit: number; debit: number }, t: Transaction) => {
    if (t.type === 'credit') {
      acc.credit += t.amount;
    } else {
      acc.debit += Math.abs(t.amount);
    }
    return acc;
  }, { credit: 0, debit: 0 });
  
  // Loading states
  const isLoading = isLoadingConnections || isLoadingTransactions;
  const isError = !!connectionsError || !!transactionsError;
  
  return (
    <>
      <Header />
      
      <motion.main 
        className="flex-1"
        initial="initial"
        animate="animate"
        exit="exit"
        variants={pageContainerVariants}
      >
        <div className="container mx-auto px-4 py-12">
          <motion.div 
            className="mb-8"
            variants={pageItemVariants}
          >
            <h1 className="text-3xl font-bold mb-2">Bank Transactions</h1>
            <p className="text-gray-400">
              View and manage transactions from your connected bank accounts
            </p>
          </motion.div>
          
          <motion.div variants={pageItemVariants}>
            {/* Connection selector */}
            <Card className="mb-6">
              <CardHeader className="pb-3">
                <CardTitle>Select Bank Account</CardTitle>
                <CardDescription>
                  Choose a connected bank account to view transactions
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isLoadingConnections ? (
                  <Skeleton className="h-10 w-full" />
                ) : connectionsError ? (
                  <div className="text-red-500 flex items-center">
                    <AlertCircle className="h-4 w-4 mr-2" />
                    Failed to load bank connections
                  </div>
                ) : connections.length === 0 ? (
                  <div className="text-center py-4">
                    <p className="text-gray-400 mb-4">You don't have any connected bank accounts yet</p>
                    <Button onClick={() => window.location.href = '/bank-connections'}>
                      <Bank className="h-4 w-4 mr-2" />
                      Connect a Bank Account
                    </Button>
                  </div>
                ) : (
                  <Select value={selectedConnection} onValueChange={setSelectedConnection}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a bank account" />
                    </SelectTrigger>
                    <SelectContent>
                      {connections.map((connection: BankConnection) => (
                        <SelectItem key={connection.id} value={connection.id}>
                          {connection.accountName} ({connection.provider}) - {connection.accountId}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              </CardContent>
            </Card>
            
            {selectedConnection && (
              <>
                {/* Filters and controls */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                  <div className="flex space-x-2">
                    <Input
                      placeholder="Search transactions..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                    <Button variant="secondary" size="icon">
                      <Search className="h-4 w-4" />
                    </Button>
                  </div>
                  
                  <Select value={transactionType} onValueChange={setTransactionType}>
                    <SelectTrigger>
                      <SelectValue placeholder="All transactions" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">All transactions</SelectItem>
                      <SelectItem value="credit">Credits only</SelectItem>
                      <SelectItem value="debit">Debits only</SelectItem>
                    </SelectContent>
                  </Select>
                  
                  <Select 
                    onValueChange={(value) => handleDateRangeChange(value as any)}
                    defaultValue="month"
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Date range" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="today">Today</SelectItem>
                      <SelectItem value="week">Last 7 days</SelectItem>
                      <SelectItem value="month">Last 30 days</SelectItem>
                      <SelectItem value="quarter">Last 3 months</SelectItem>
                      <SelectItem value="year">Last year</SelectItem>
                      <SelectItem value="custom">Custom range</SelectItem>
                    </SelectContent>
                  </Select>
                  
                  <div className="flex space-x-2">
                    <Button 
                      variant="outline" 
                      className="flex-1"
                      onClick={() => refetchTransactions()}
                    >
                      <RefreshCw className="h-4 w-4 mr-2" />
                      Refresh
                    </Button>
                    <Button 
                      variant="outline" 
                      className="flex-1"
                      onClick={exportTransactions}
                      disabled={!filteredTransactions.length}
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Export
                    </Button>
                  </div>
                </div>
                
                {/* Transaction summary */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg">Total Credits</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold text-green-500">
                        {formatCurrency(totals.credit)}
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg">Total Debits</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold text-red-500">
                        {formatCurrency(totals.debit)}
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg">Net Balance</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className={`text-2xl font-bold ${
                        totals.credit - totals.debit >= 0 ? 'text-green-500' : 'text-red-500'
                      }`}>
                        {formatCurrency(totals.credit - totals.debit)}
                      </div>
                    </CardContent>
                  </Card>
                </div>
                
                {/* Transactions list */}
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <h2 className="text-xl font-bold">Transactions</h2>
                    <div className="text-sm text-gray-400">
                      {filteredTransactions.length} transactions found
                    </div>
                  </div>
                  
                  {isLoadingTransactions ? (
                    // Loading skeletons
                    Array.from({ length: 5 }).map((_, i) => (
                      <Skeleton key={`skeleton-${i}`} className="h-20 w-full" />
                    ))
                  ) : transactionsError ? (
                    <Card>
                      <CardContent className="p-6 text-center">
                        <AlertCircle className="h-8 w-8 mx-auto text-red-500 mb-2" />
                        <h3 className="text-lg font-medium mb-1">Failed to load transactions</h3>
                        <p className="text-gray-400 mb-4">
                          There was an error loading your transactions. Please try again.
                        </p>
                        <Button onClick={() => refetchTransactions()}>
                          <RefreshCw className="h-4 w-4 mr-2" />
                          Retry
                        </Button>
                      </CardContent>
                    </Card>
                  ) : filteredTransactions.length === 0 ? (
                    <Card>
                      <CardContent className="p-6 text-center">
                        <Calendar className="h-8 w-8 mx-auto text-gray-400 mb-2" />
                        <h3 className="text-lg font-medium mb-1">No transactions found</h3>
                        <p className="text-gray-400">
                          {searchTerm || transactionType 
                            ? "Try adjusting your filters to see more results" 
                            : "There are no transactions for the selected period"}
                        </p>
                      </CardContent>
                    </Card>
                  ) : (
                    <div className="space-y-2">
                      {filteredTransactions.map((transaction: Transaction) => (
                        <TransactionCard key={transaction.id} transaction={transaction} />
                      ))}
                    </div>
                  )}
                </div>
              </>
            )}
          </motion.div>
        </div>
      </motion.main>
      
      <Footer />
    </>
  );
}
