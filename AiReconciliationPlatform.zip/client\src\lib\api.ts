/**
 * API Client Library
 * 
 * This module provides functions to interact with the backend API endpoints.
 * It handles authentication, error handling, and provides typed responses.
 */

import { QueryClient } from '@tanstack/react-query';
import { bankIntegrationsApi } from './bankIntegrationsApi';

// Base API URL - in production, this would be configured based on environment
const API_BASE_URL = '/api';

// Interface for API response
interface ApiResponse<T> {
  success: boolean;
  data?: T;
  message?: string;
  errors?: any;
}

// Interface for login request
interface LoginRequest {
  username: string;
  password: string;
}

// Interface for registration request
interface RegisterRequest {
  email: string;
  username: string;
  password: string;
  userType: 'business' | 'individual' | 'admin';
  companyName?: string;
}

// Interface for user data
export interface User {
  id: string;
  username: string;
  email: string;
  userType: string;
  companyName?: string;
}

// Interface for auth response
interface AuthResponse {
  user: User;
  token: string;
}

// Interface for feature flag
export interface FeatureFlag {
  id: string;
  name: string;
  displayName: string;
  description: string;
  enabled: boolean;
  createdAt: string;
  updatedAt: string;
}

// Interface for audit log
export interface AuditLog {
  id: string;
  action: string;
  resourceId: string;
  resourceType: string;
  userId: string;
  details: any;
  timestamp: string;
}

// Interface for analytics data
export interface AnalyticsData {
  users: {
    total: number;
  };
  transactions: {
    total: number;
    reconciled: number;
    successRate: number;
  };
  disputes: {
    total: number;
  };
  connections: {
    total: number;
  };
  recentActivity: AuditLog[];
}

// Interface for bank integration
export interface BankIntegration {
  id: string;
  provider: string;
  name: string;
  displayName: string;
  description: string;
  status: 'active' | 'maintenance' | 'deprecated' | 'disabled';
  features: {
    accountInfo: boolean;
    transactions: boolean;
    payments: boolean;
    beneficiaries: boolean;
    statements: boolean;
  };
  apiVersion: string;
  documentationUrl: string;
  supportEmail: string;
}

// Helper function to handle API errors
const handleApiError = (error: any): never => {
  console.error('API Error:', error);
  
  if (error.response) {
    // The request was made and the server responded with a status code
    // that falls out of the range of 2xx
    throw new Error(error.response.data.message || 'Server error');
  } else if (error.request) {
    // The request was made but no response was received
    throw new Error('No response from server. Please check your connection.');
  } else {
    // Something happened in setting up the request that triggered an Error
    throw new Error(error.message || 'Error setting up request');
  }
};

// Helper function to get auth token
const getAuthToken = (): string | null => {
  return localStorage.getItem('authToken');
};

// Helper function to get admin token
const getAdminToken = (): string | null => {
  return localStorage.getItem('adminToken');
};

// Helper function to set auth headers
const getAuthHeaders = (isAdmin = false): HeadersInit => {
  const token = isAdmin ? getAdminToken() : getAuthToken();
  
  return {
    'Content-Type': 'application/json',
    ...(token ? { 'Authorization': `Bearer ${token}` } : {})
  };
};

// Generic fetch function with error handling
export async function apiFetch<T>(
  endpoint: string,
  options: RequestInit = {},
  isAdmin = false
): Promise<T> {
  try {
    const url = `${API_BASE_URL}${endpoint}`;
    const headers = {
      ...getAuthHeaders(isAdmin),
      ...options.headers
    };
    
    const response = await fetch(url, {
      ...options,
      headers
    });
    
    const data = await response.json();
    
    if (!response.ok) {
      throw {
        response: {
          status: response.status,
          data
        }
      };
    }
    
    return data;
  } catch (error) {
    return handleApiError(error);
  }
}

// Authentication API functions
export const authApi = {
  // Login function
  login: async (credentials: LoginRequest): Promise<AuthResponse> => {
    try {
      const response = await apiFetch<any>(
        '/auth/login',
        {
          method: 'POST',
          body: JSON.stringify(credentials)
        }
      );
      
      // Server returns the response directly, not wrapped in success/data
      if (response && response.token) {
        // Store token in localStorage
        localStorage.setItem('authToken', response.token);
        localStorage.setItem('userData', JSON.stringify(response.user));
        return response;
      }
      
      throw new Error('Login failed - Invalid response format');
    } catch (error) {
      console.error('Login error:', error);
      throw error;
    }
  },
  
  // Register function
  register: async (userData: RegisterRequest): Promise<AuthResponse> => {
    try {
      // Map client-side fields to server-side expected fields
      const serverUserData = {
        username: userData.username,
        password: userData.password,
        fullName: userData.email, // Using email as fullName since server expects fullName
        role: userData.userType === 'admin' ? 'admin' : 'user'
      };

      const response = await apiFetch<any>(
        '/auth/register',
        {
          method: 'POST',
          body: JSON.stringify(serverUserData)
        }
      );
      
      // Server returns the response directly, not wrapped in success/data
      if (response && response.token) {
        // Store token in localStorage
        localStorage.setItem('authToken', response.token);
        localStorage.setItem('userData', JSON.stringify(response.user));
        return response;
      }
      
      throw new Error('Registration failed - Invalid response format');
    } catch (error) {
      console.error('Registration error:', error);
      throw error;
    }
  },
  
  // Logout function
  logout: () => {
    localStorage.removeItem('authToken');
    localStorage.removeItem('userData');
  },
  
  // Get current user
  getCurrentUser: (): User | null => {
    const userData = localStorage.getItem('userData');
    return userData ? JSON.parse(userData) : null;
  },
  
  // Check if user is authenticated
  isAuthenticated: (): boolean => {
    return !!getAuthToken();
  },
  
  // Admin login
  adminLogin: async (credentials: LoginRequest): Promise<string> => {
    const response = await apiFetch<ApiResponse<{ token: string }>>(
      '/admin/login',
      {
        method: 'POST',
        body: JSON.stringify(credentials)
      }
    );
    
    if (response.success && response.data) {
      // Store admin token in localStorage
      localStorage.setItem('adminToken', response.data.token);
      return response.data.token;
    }
    
    throw new Error(response.message || 'Admin login failed');
  },
  
  // Check if admin is authenticated
  isAdminAuthenticated() {
    return !!localStorage.getItem('adminToken');
  },
  
  // Admin logout
  adminLogout() {
    localStorage.removeItem('adminToken');
  }
};

// Admin API functions
export const adminApi = {
  // Get analytics data
  getAnalytics: async (): Promise<AnalyticsData> => {
    const response = await apiFetch<ApiResponse<AnalyticsData>>(
      '/admin/analytics',
      {},
      true
    );
    
    if (response.success && response.data) {
      return response.data;
    }
    
    throw new Error(response.message || 'Failed to fetch analytics data');
  },
  
  // Get feature flags
  getFeatureFlags: async (): Promise<FeatureFlag[]> => {
    const response = await apiFetch<ApiResponse<FeatureFlag[]>>(
      '/admin/features',
      {},
      true
    );
    
    if (response.success && response.data) {
      return response.data;
    }
    
    throw new Error(response.message || 'Failed to fetch feature flags');
  },
  
  // Update feature flag
  updateFeatureFlag: async (id: string, enabled: boolean): Promise<void> => {
    const response = await apiFetch<ApiResponse<void>>(
      `/admin/features/${id}`,
      {
        method: 'PUT',
        body: JSON.stringify({ enabled })
      },
      true
    );
    
    if (!response.success) {
      throw new Error(response.message || 'Failed to update feature flag');
    }
  },
  
  // Get audit logs
  getAuditLogs: async (page = 1, limit = 20): Promise<{ logs: AuditLog[], pagination: any }> => {
    const response = await apiFetch<ApiResponse<{ logs: AuditLog[], pagination: any }>>(
      `/admin/audit-logs?page=${page}&limit=${limit}`,
      {},
      true
    );
    
    if (response.success && response.data) {
      return response.data;
    }
    
    throw new Error(response.message || 'Failed to fetch audit logs');
  },
  
  // Get bank integrations
  getBankIntegrations: async (): Promise<BankIntegration[]> => {
    const response = await apiFetch<ApiResponse<BankIntegration[]>>(
      '/admin/bank-integrations',
      {},
      true
    );
    
    if (response.success && response.data) {
      return response.data;
    }
    
    throw new Error(response.message || 'Failed to fetch bank integrations');
  },
  
  // Update bank integration status
  updateBankIntegrationStatus: async (
    id: string,
    status: 'active' | 'maintenance' | 'deprecated' | 'disabled'
  ): Promise<void> => {
    const response = await apiFetch<ApiResponse<void>>(
      `/admin/bank-integrations/${id}/status`,
      {
        method: 'PUT',
        body: JSON.stringify({ status })
      },
      true
    );
    
    if (!response.success) {
      throw new Error(response.message || 'Failed to update bank integration status');
    }
  }
};

// User API functions
export const userApi = {
  // Get user profile
  getProfile: async (): Promise<User> => {
    const response = await apiFetch<ApiResponse<User>>(
      '/user/profile',
      {}
    );
    
    if (response.success && response.data) {
      return response.data;
    }
    
    throw new Error(response.message || 'Failed to fetch user profile');
  },
  
  // Update user profile
  updateProfile: async (profileData: Partial<User>): Promise<User> => {
    const response = await apiFetch<ApiResponse<User>>(
      '/user/profile',
      {
        method: 'PUT',
        body: JSON.stringify(profileData)
      }
    );
    
    if (response.success && response.data) {
      // Update stored user data
      const currentUser = authApi.getCurrentUser();
      if (currentUser) {
        localStorage.setItem('userData', JSON.stringify({
          ...currentUser,
          ...response.data
        }));
      }
      
      return response.data;
    }
    
    throw new Error(response.message || 'Failed to update user profile');
  }
};

// Support Chatbot API functions
export interface ChatMessage {
  id?: string;
  userId: string;
  type: 'user' | 'bot';
  content: string;
  timestamp: Date;
  metadata?: Record<string, any>;
}

export interface ChatSession {
  id?: string;
  userId: string;
  messages: ChatMessage[];
  createdAt: Date;
  updatedAt: Date;
  isActive: boolean;
}

export const supportChatbotApi = {
  // Create a new chat session
  createChatSession: async (): Promise<ChatSession> => {
    const user = authApi.getCurrentUser();
    if (!user) {
      throw new Error('User must be authenticated to create a chat session');
    }
    
    return apiFetch<ChatSession>(
      `${API_BASE_URL}/support/sessions`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ userId: user.id }),
      }
    );
  },
  
  // Get a chat session by ID
  getChatSession: async (sessionId: string): Promise<ChatSession> => {
    return apiFetch<ChatSession>(
      `${API_BASE_URL}/support/sessions/${sessionId}`,
      {
        method: 'GET',
      }
    );
  },
  
  // Send a message in a chat session
  sendMessage: async (sessionId: string, content: string): Promise<{ userMessage: ChatMessage, botMessage: ChatMessage }> => {
    const user = authApi.getCurrentUser();
    if (!user) {
      throw new Error('User must be authenticated to send a message');
    }
    
    return apiFetch<{ userMessage: ChatMessage, botMessage: ChatMessage }>(
      `${API_BASE_URL}/support/sessions/${sessionId}/messages`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ userId: user.id, content }),
      }
    );
  },
  
  // Close a chat session
  closeChatSession: async (sessionId: string): Promise<void> => {
    return apiFetch<void>(
      `${API_BASE_URL}/support/sessions/${sessionId}/close`,
      {
        method: 'PUT',
      }
    );
  },
};

// Export the combined API
export const api = {
  auth: authApi,
  admin: adminApi,
  user: userApi,
  supportChatbot: supportChatbotApi,
  bankIntegrations: bankIntegrationsApi
};

// Initialize query client
export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      retry: 1,
      staleTime: 5 * 60 * 1000, // 5 minutes
    },
  },
});

// Export default API object
export default {
  auth: authApi,
  admin: adminApi,
  user: userApi,
  supportChatbot: supportChatbotApi
};
