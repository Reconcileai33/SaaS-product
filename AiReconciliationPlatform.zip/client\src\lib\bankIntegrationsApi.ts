/**
 * Bank Integrations API Client
 * 
 * This module provides functions to interact with the bank integrations API endpoints.
 */

// Define API base URL directly to avoid circular dependencies
const API_BASE_URL = '/api';

// Redefining apiFetch here to avoid circular dependencies
async function apiFetch<T>(endpoint: string, options: RequestInit = {}, isAdmin = false): Promise<T> {
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    ...options.headers,
  };

  // Add auth token if available
  const token = isAdmin ? localStorage.getItem('adminToken') : localStorage.getItem('token');
  if (token) {
    // Use type assertion to avoid TypeScript error
    (headers as Record<string, string>)['Authorization'] = `Bearer ${token}`;
  }

  const response = await fetch(endpoint, {
    ...options,
    headers,
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(errorData.message || `API error: ${response.status}`);
  }

  return response.json();
}

// Interface for bank account details
export interface BankAccountDetails {
  accountId: string;
  accountNumber: string;
  accountType: string;
  balance: number;
  currency: string;
  bankName: string;
  holderName: string;
  ifscCode?: string;
  swiftCode?: string;
  status: 'active' | 'inactive' | 'blocked';
  lastUpdated: string;
}

// Interface for transaction analytics
export interface TransactionAnalytics {
  totalTransactions: number;
  totalCredits: number;
  totalDebits: number;
  netBalance: number;
  averageTransactionAmount: number;
  categories: Record<string, number>;
  dailyVolume: {
    date: string;
    volume: number;
    count: number;
  }[];
}

// Interface for bank connection
export interface BankConnection {
  id: string;
  userId: string;
  provider: string;
  accountId?: string;
  status: 'pending' | 'active' | 'expired' | 'revoked' | 'failed';
  createdAt: string;
  updatedAt: string;
}

// Bank Integrations API functions
export const bankIntegrationsApi = {
  // Get all available bank integrations
  getAvailableBankIntegrations: async () => {
    return apiFetch<any[]>(`${API_BASE_URL}/bank-integrations`);
  },

  // Get user's bank connections
  getUserConnections: async () => {
    return apiFetch<BankConnection[]>(`${API_BASE_URL}/bank-integrations/connections`);
  },

  // Generate authorization URL for connecting to a bank
  generateAuthUrl: async (provider: string) => {
    return apiFetch<{ url: string }>(`${API_BASE_URL}/bank-integrations/${provider}/auth-url`, {
      method: 'GET'
    });
  },

  // Revoke a bank connection
  revokeConnection: async (connectionId: string) => {
    return apiFetch<{ success: boolean }>(`${API_BASE_URL}/bank-integrations/connections/${connectionId}/revoke`, {
      method: 'POST'
    });
  },

  // Synchronize transactions for a bank connection
  syncTransactions: async (connectionId: string, startDate?: string, endDate?: string) => {
    const queryParams = new URLSearchParams();
    if (startDate) queryParams.append('startDate', startDate);
    if (endDate) queryParams.append('endDate', endDate);
    
    const queryString = queryParams.toString() ? `?${queryParams.toString()}` : '';
    
    return apiFetch<{ success: boolean, message: string, data: any }>(
      `${API_BASE_URL}/bank-integrations/connections/${connectionId}/sync${queryString}`,
      {
        method: 'POST'
      }
    );
  },

  // Get bank account details
  getBankAccountDetails: async (connectionId: string) => {
    return apiFetch<BankAccountDetails>(
      `${API_BASE_URL}/bank-integrations/connections/${connectionId}/account`,
      {
        method: 'GET'
      }
    );
  },

  // Get transaction analytics
  getTransactionAnalytics: async (connectionId: string) => {
    return apiFetch<TransactionAnalytics>(
      `${API_BASE_URL}/bank-integrations/connections/${connectionId}/analytics`,
      {
        method: 'GET'
      }
    );
  },

  // Check bank integration health
  checkIntegrationHealth: async (provider: string) => {
    return apiFetch<{ status: 'operational' | 'degraded' | 'outage' | 'maintenance', lastChecked: string }>(
      `${API_BASE_URL}/bank-integrations/${provider}/health`,
      {
        method: 'GET'
      },
      true // Admin only endpoint
    );
  }
};
