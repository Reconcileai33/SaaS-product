
import { Route, useLocation } from "wouter";
import { ReactNode, useEffect } from "react";
import Layout from "@/components/layout/Layout";
import { authApi } from "./api";

interface ProtectedRouteProps {
  path: string;
  children: ReactNode;
}

export function ProtectedRoute({ path, children }: ProtectedRouteProps) {
  const isAuthenticated = authApi.isAuthenticated();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!isAuthenticated) {
      // Clear any invalid auth data
      authApi.logout();
      setLocation("/auth");
    }
  }, [isAuthenticated, path, setLocation]);

  if (!isAuthenticated) {
    return null;
  }

  return (
    <Route path={path}>
      <Layout>{children}</Layout>
    </Route>
  );
}

export function PublicOnlyRoute({ path, children }: ProtectedRouteProps) {
  const isAuthenticated = authApi.isAuthenticated();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (isAuthenticated && path === "/auth") {
      setLocation("/dashboard");
    }
  }, [isAuthenticated, path, setLocation]);

  if (isAuthenticated && path === "/auth") {
    return null;
  }

  return <Route path={path}>{children}</Route>;
}
