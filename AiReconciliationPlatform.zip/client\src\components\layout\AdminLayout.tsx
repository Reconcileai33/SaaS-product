import { ReactNode } from "react";
import { motion } from "framer-motion";
import { Link, useLocation } from "wouter";
import { 
  LayoutDashboard, 
  Settings, 
  Users, 
  Database, 
  LogOut, 
  Activity,
  Layers
} from "lucide-react";
import { authApi } from "@/lib/api";

interface AdminLayoutProps {
  children: ReactNode;
}

const AdminLayout = ({ children }: AdminLayoutProps) => {
  const [location] = useLocation();

  const handleLogout = () => {
    authApi.adminLogout();
    window.location.href = "/admin/login";
  };

  return (
    <div className="flex h-screen bg-slate-900">
      {/* Sidebar */}
      <motion.div 
        className="w-64 bg-black border-r border-slate-800 p-4 hidden md:block"
        initial={{ x: -50, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ duration: 0.3 }}
      >
        {/* Logo */}
        <Link href="/admin/dashboard">
          <div className="flex items-center mb-8 mt-2">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-r from-amber-500 to-yellow-400 p-[2px] mr-2">
              <div className="w-full h-full rounded-lg bg-black flex items-center justify-center">
                <span className="text-xl font-bold text-amber-400">R</span>
              </div>
            </div>
            <div className="flex flex-col leading-tight">
              <span className="text-xl font-bold bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-500 text-transparent bg-clip-text">
                Admin
              </span>
              <span className="text-sm font-bold text-amber-500/80 -mt-1">Panel</span>
            </div>
          </div>
        </Link>
        
        {/* Navigation */}
        <nav className="space-y-1">
          <NavItem 
            href="/admin/dashboard" 
            icon={<LayoutDashboard size={18} />} 
            isActive={location === "/admin/dashboard"}
          >
            Dashboard
          </NavItem>
          <NavItem 
            href="/admin/users" 
            icon={<Users size={18} />} 
            isActive={location === "/admin/users"}
          >
            Users
          </NavItem>
          <NavItem 
            href="/admin/integrations" 
            icon={<Database size={18} />} 
            isActive={location === "/admin/integrations"}
          >
            Integrations
          </NavItem>
          <NavItem 
            href="/admin/audit-trail" 
            icon={<Activity size={18} />} 
            isActive={location === "/admin/audit-trail"}
          >
            Audit Trail
          </NavItem>
          <NavItem 
            href="/admin/features" 
            icon={<Layers size={18} />} 
            isActive={location === "/admin/features"}
          >
            Features
          </NavItem>
          <NavItem 
            href="/admin/settings" 
            icon={<Settings size={18} />} 
            isActive={location === "/admin/settings"}
          >
            Settings
          </NavItem>
          
          {/* Logout */}
          <button 
            onClick={handleLogout}
            className="flex items-center w-full px-3 py-2 text-sm font-medium rounded-md text-slate-300 hover:bg-slate-800 hover:text-amber-400 transition-colors"
          >
            <LogOut size={18} className="mr-2" />
            Logout
          </button>
        </nav>
      </motion.div>
      
      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Mobile Header */}
        <div className="md:hidden bg-black border-b border-slate-800 p-4">
          <div className="flex items-center justify-between">
            <Link href="/admin/dashboard">
              <div className="flex items-center">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-r from-amber-500 to-yellow-400 p-[2px] mr-2">
                  <div className="w-full h-full rounded-lg bg-black flex items-center justify-center">
                    <span className="text-lg font-bold text-amber-400">R</span>
                  </div>
                </div>
                <div className="flex flex-col leading-tight">
                  <span className="text-lg font-bold bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-500 text-transparent bg-clip-text">
                    Admin
                  </span>
                </div>
              </div>
            </Link>
          </div>
        </div>
        
        {/* Content */}
        <main className="flex-1 overflow-y-auto bg-slate-900 p-6">
          {children}
        </main>
      </div>
    </div>
  );
};

interface NavItemProps {
  href: string;
  icon: ReactNode;
  children: ReactNode;
  isActive: boolean;
}

const NavItem = ({ href, icon, children, isActive }: NavItemProps) => {
  return (
    <Link href={href}>
      <a className={`flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors ${
        isActive 
          ? "bg-slate-800 text-amber-400" 
          : "text-slate-300 hover:bg-slate-800 hover:text-amber-400"
      }`}>
        <span className="mr-2">{icon}</span>
        {children}
      </a>
    </Link>
  );
};

export default AdminLayout;
