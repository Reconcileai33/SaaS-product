import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { 
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Search, PlusCircle, Info } from "lucide-react";
import { adminApi } from "@/lib/api";
import { pageContainerVariants } from "@/lib/animations";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";

// Feature flag schema
const featureSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  displayName: z.string().min(2, "Display name must be at least 2 characters"),
  description: z.string().min(10, "Description must be at least 10 characters"),
  enabled: z.boolean().default(false),
});

type FeatureFormValues = z.infer<typeof featureSchema>;

export default function AdminFeatures() {
  const [features, setFeatures] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { toast } = useToast();

  const form = useForm<FeatureFormValues>({
    resolver: zodResolver(featureSchema),
    defaultValues: {
      name: "",
      displayName: "",
      description: "",
      enabled: false,
    },
  });

  // Fetch features from API
  useEffect(() => {
    const fetchFeatures = async () => {
      try {
        setIsLoading(true);
        // In a real implementation, we would fetch from the API
        // const fetchedFeatures = await adminApi.getFeatureFlags();
        // setFeatures(fetchedFeatures);
        
        // For now, simulate API call with mock data
        setTimeout(() => {
          setFeatures([
            {
              id: "1",
              name: "ai_matching",
              displayName: "AI Matching",
              description: "Enable AI-powered transaction matching for better accuracy",
              enabled: true,
              createdAt: "2025-01-15T08:00:00Z",
              updatedAt: "2025-05-01T10:30:00Z"
            },
            {
              id: "2",
              name: "predictive_analytics",
              displayName: "Predictive Analytics",
              description: "Enable predictive analytics for forecasting future transactions",
              enabled: false,
              createdAt: "2025-02-20T09:30:00Z",
              updatedAt: "2025-04-25T14:20:00Z"
            },
            {
              id: "3",
              name: "smart_routing",
              displayName: "Smart Routing",
              description: "Enable intelligent routing of payments based on cost and speed",
              enabled: true,
              createdAt: "2025-03-05T11:15:00Z",
              updatedAt: "2025-05-10T16:45:00Z"
            },
            {
              id: "4",
              name: "multi_currency",
              displayName: "Multi-Currency Support",
              description: "Enable support for multiple currencies in transactions",
              enabled: false,
              createdAt: "2025-03-10T13:45:00Z",
              updatedAt: "2025-04-15T09:20:00Z"
            }
          ]);
          setIsLoading(false);
        }, 500);
      } catch (error) {
        console.error("Error fetching features:", error);
        setIsLoading(false);
      }
    };

    fetchFeatures();
  }, []);

  // Filter features based on search term
  const filteredFeatures = features.filter(feature => 
    feature.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    feature.displayName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    feature.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Handle feature toggle
  const handleToggleFeature = async (id: string, currentStatus: boolean) => {
    try {
      // In a real implementation, we would update via API
      // await adminApi.updateFeatureFlag(id, { enabled: !currentStatus });
      
      // For now, update local state
      setFeatures(features.map(feature => 
        feature.id === id 
          ? { ...feature, enabled: !currentStatus, updatedAt: new Date().toISOString() } 
          : feature
      ));
      
      toast({
        title: "Feature updated",
        description: `Feature has been ${!currentStatus ? "enabled" : "disabled"}.`,
      });
    } catch (error) {
      console.error("Error updating feature:", error);
      toast({
        title: "Update failed",
        description: "There was an error updating the feature.",
        variant: "destructive",
      });
    }
  };

  // Handle form submission
  const onSubmit = async (data: FeatureFormValues) => {
    try {
      // In a real implementation, we would create via API
      // const newFeature = await adminApi.createFeatureFlag(data);
      
      // For now, update local state with mock data
      const newFeature = {
        id: Date.now().toString(),
        ...data,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      
      setFeatures([...features, newFeature]);
      
      toast({
        title: "Feature created",
        description: "New feature flag has been created successfully.",
      });
      
      form.reset();
      setIsDialogOpen(false);
    } catch (error) {
      console.error("Error creating feature:", error);
      toast({
        title: "Creation failed",
        description: "There was an error creating the feature.",
        variant: "destructive",
      });
    }
  };

  // Format date for display
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  return (
    <motion.div
      className="space-y-6"
      variants={pageContainerVariants}
      initial="hidden"
      animate="visible"
    >
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Feature Management</h1>
          <p className="text-slate-400">Control feature flags and platform capabilities</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="btn-primary">
              <PlusCircle size={16} className="mr-2" />
              Add Feature
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-slate-800 border-slate-700 text-white">
            <DialogHeader>
              <DialogTitle>Create New Feature Flag</DialogTitle>
              <DialogDescription className="text-slate-400">
                Add a new feature flag to control functionality across the platform.
              </DialogDescription>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Feature Key</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="e.g. multi_currency_support" 
                          className="bg-slate-900 border-slate-700"
                          {...field} 
                        />
                      </FormControl>
                      <FormDescription className="text-slate-500">
                        This is the technical key used in code.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="displayName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Display Name</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="e.g. Multi-Currency Support" 
                          className="bg-slate-900 border-slate-700"
                          {...field} 
                        />
                      </FormControl>
                      <FormDescription className="text-slate-500">
                        Human-readable name shown in the UI.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Describe what this feature does..." 
                          className="bg-slate-900 border-slate-700 min-h-[80px]"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="enabled"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border border-slate-700 p-3 shadow-sm">
                      <div className="space-y-0.5">
                        <FormLabel>Enabled</FormLabel>
                        <FormDescription className="text-slate-500">
                          Enable this feature immediately?
                        </FormDescription>
                      </div>
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                <DialogFooter>
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setIsDialogOpen(false)}
                    className="bg-slate-900 border-slate-700 text-slate-300"
                  >
                    Cancel
                  </Button>
                  <Button type="submit" className="btn-primary">
                    Create Feature
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="bg-slate-800 border-slate-700">
        <CardHeader className="pb-3">
          <CardTitle className="text-white">Feature Flags</CardTitle>
          <CardDescription>
            Total features: {features.length}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="relative mb-6">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400" size={18} />
            <Input
              placeholder="Search features..."
              className="pl-10 bg-slate-900 border-slate-700"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <div className="rounded-md border border-slate-700 overflow-hidden">
            <Table>
              <TableHeader className="bg-slate-900">
                <TableRow className="hover:bg-slate-800/50 border-slate-700">
                  <TableHead className="text-slate-300">Feature</TableHead>
                  <TableHead className="text-slate-300">Description</TableHead>
                  <TableHead className="text-slate-300">Status</TableHead>
                  <TableHead className="text-slate-300">Last Updated</TableHead>
                  <TableHead className="text-slate-300 text-right">Toggle</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-8 text-slate-400">
                      Loading features...
                    </TableCell>
                  </TableRow>
                ) : filteredFeatures.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-8 text-slate-400">
                      No features found
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredFeatures.map((feature) => (
                    <TableRow key={feature.id} className="hover:bg-slate-800/50 border-slate-700">
                      <TableCell>
                        <div className="font-medium text-white">{feature.displayName}</div>
                        <div className="text-sm text-slate-400">{feature.name}</div>
                      </TableCell>
                      <TableCell className="text-slate-300 max-w-md">
                        <div className="flex items-start">
                          <Info size={16} className="mr-2 mt-0.5 text-slate-400 flex-shrink-0" />
                          <span>{feature.description}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge 
                          variant={feature.enabled ? "default" : "secondary"} 
                          className={`capitalize ${feature.enabled ? "bg-green-500 hover:bg-green-600" : ""}`}
                        >
                          {feature.enabled ? "Enabled" : "Disabled"}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-slate-300">{formatDate(feature.updatedAt)}</TableCell>
                      <TableCell className="text-right">
                        <Switch
                          checked={feature.enabled}
                          onCheckedChange={() => handleToggleFeature(feature.id, feature.enabled)}
                        />
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
