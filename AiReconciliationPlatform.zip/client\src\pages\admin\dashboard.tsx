import { motion } from "framer-motion";
import { pageContainerVariants, pageItemVariants } from "@/lib/animations";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from "recharts";
import { ArrowUpRight, Download, Users, CreditCard, AlertTriangle, CheckCircle, Clock, Settings, Database, Shield, Loader2, ToggleLeft, ToggleRight, AlertCircle } from "lucide-react";
import { useEffect, useState, useMemo } from "react";
import { useRouter } from "wouter";
import { adminApi, authApi } from "@/lib/api";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";

// Interface for feature flag
interface FeatureFlag {
  id: string;
  name: string;
  displayName: string;
  description: string;
  enabled: boolean;
  createdAt: string;
  updatedAt: string;
}

// Interface for audit log
interface AuditLog {
  id: string;
  action: string;
  resourceId: string;
  resourceType: string;
  userId: string;
  details: any;
  timestamp: string;
}

// Colors for charts
const COLORS = ['#10B981', '#F59E0B', '#EF4444'];

// Helper function to format numbers with Indian currency format
const formatIndianCurrency = (value: number): string => {
  if (value >= 10000000) { // 1 crore or more
    return `₹${(value / 10000000).toFixed(1)}Cr`;
  } else if (value >= 100000) { // 1 lakh or more
    return `₹${(value / 100000).toFixed(1)}L`;
  } else if (value >= 1000) { // 1 thousand or more
    return `₹${(value / 1000).toFixed(1)}K`;
  } else {
    return `₹${value}`;
  }
};

// Helper function to generate monthly data from analytics
const generateMonthlyData = (startCount: number, growthRate: number = 1.2): { month: string, users: number }[] => {
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const currentMonth = new Date().getMonth();
  
  return months.slice(0, currentMonth + 1).map((month, index) => {
    const userCount = Math.round(startCount * Math.pow(growthRate, index));
    return { month, users: userCount };
  });
};

// Helper function to generate monthly transaction volume data
const generateTransactionVolumeData = (startVolume: number, growthRate: number = 1.15): { month: string, volume: number }[] => {
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const currentMonth = new Date().getMonth();
  
  return months.slice(0, currentMonth + 1).map((month, index) => {
    const volume = Math.round(startVolume * Math.pow(growthRate, index));
    return { month, volume };
  });
};

export default function AdminDashboard() {
  const [, setLocation] = useRouter();
  const queryClient = useQueryClient();
  const [isUpdatingFeature, setIsUpdatingFeature] = useState(false);
  
  // Check if admin is authenticated
  useEffect(() => {
    if (!authApi.isAdminAuthenticated()) {
      setLocation('/admin/login');
    }
  }, [setLocation]);
  
  // Fetch analytics data
  const { 
    data: analyticsData,
    isLoading: isAnalyticsLoading,
    error: analyticsError 
  } = useQuery({
    queryKey: ['adminAnalytics'],
    queryFn: () => adminApi.getAnalytics(),
    enabled: authApi.isAdminAuthenticated()
  });
  
  // Fetch feature flags
  const {
    data: featureFlags = [],
    isLoading: isFlagsLoading,
    error: flagsError
  } = useQuery({
    queryKey: ['featureFlags'],
    queryFn: () => adminApi.getFeatureFlags(),
    enabled: authApi.isAdminAuthenticated()
  });
  
  // Fetch audit logs
  const {
    data: auditLogsData,
    isLoading: isLogsLoading,
    error: logsError
  } = useQuery({
    queryKey: ['auditLogs'],
    queryFn: () => adminApi.getAuditLogs(1, 5),
    enabled: authApi.isAdminAuthenticated()
  });
  
  // Fetch bank integrations
  const {
    data: bankIntegrations = [],
    isLoading: isIntegrationsLoading,
    error: integrationsError
  } = useQuery({
    queryKey: ['bankIntegrations'],
    queryFn: () => adminApi.getBankIntegrations(),
    enabled: authApi.isAdminAuthenticated()
  });
  
  // Computed values from API data
  const activeUsers = analyticsData?.users?.total || 0;
  const totalTransactions = analyticsData?.transactions?.total || 0;
  const totalVolume = analyticsData?.transactions?.volume || 0;
  const reconciledRate = analyticsData?.transactions?.successRate || 0;
  const auditLogs = auditLogsData?.logs || [];
  
  // Generate chart data from analytics
  const userStats = useMemo(() => {
    return generateMonthlyData(activeUsers / 2);
  }, [activeUsers]);
  
  const transactionVolume = useMemo(() => {
    return generateTransactionVolumeData(totalVolume / 3);
  }, [totalVolume]);
  
  // Generate dispute data
  const disputeData = useMemo(() => {
    const resolvedPercent = reconciledRate;
    const pendingPercent = Math.round((100 - resolvedPercent) * 0.7);
    const escalatedPercent = 100 - resolvedPercent - pendingPercent;
    
    return [
      { name: 'Resolved', value: resolvedPercent },
      { name: 'Pending', value: pendingPercent },
      { name: 'Escalated', value: escalatedPercent },
    ];
  }, [reconciledRate]);
  
  // Format integration data
  const integrationStatus = useMemo(() => {
    return bankIntegrations.map(integration => {
      // Calculate estimated users and volume based on analytics data
      const estimatedUsers = Math.round(activeUsers * (Math.random() * 0.3 + 0.1));
      const estimatedVolume = Math.round(totalVolume * (Math.random() * 0.3 + 0.1));
      
      return {
        name: integration.displayName,
        status: integration.status,
        users: estimatedUsers,
        volume: formatIndianCurrency(estimatedVolume)
      };
    });
  }, [bankIntegrations, activeUsers, totalVolume]);
  
  // Check if any data is loading
  const isLoading = isAnalyticsLoading || isFlagsLoading || isLogsLoading || isIntegrationsLoading;
  
  // Combine all errors
  const error = analyticsError?.message || flagsError?.message || logsError?.message || integrationsError?.message || '';
  
  // Feature flag toggle mutation
  const updateFeatureMutation = useMutation({
    mutationFn: ({ id, enabled }: { id: string; enabled: boolean }) => {
      return adminApi.updateFeatureFlag(id, enabled);
    },
    onMutate: ({ id, enabled }) => {
      setIsUpdatingFeature(true);
      
      // Optimistic update
      const previousFlags = queryClient.getQueryData<FeatureFlag[]>(['featureFlags']);
      
      if (previousFlags) {
        queryClient.setQueryData(['featureFlags'], 
          previousFlags.map(flag => 
            flag.id === id ? { ...flag, enabled } : flag
          )
        );
      }
      
      return { previousFlags };
    },
    onError: (err, variables, context) => {
      // Rollback on error
      if (context?.previousFlags) {
        queryClient.setQueryData(['featureFlags'], context.previousFlags);
      }
      console.error('Error updating feature flag:', err);
    },
    onSettled: () => {
      setIsUpdatingFeature(false);
      queryClient.invalidateQueries({ queryKey: ['featureFlags'] });
    }
  });
  
  // Toggle feature flag
  const toggleFeatureFlag = (id: string, enabled: boolean) => {
    updateFeatureMutation.mutate({ id, enabled: !enabled });
  };
  
  // Format date for audit logs
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString();
  };
  
  return (
    <div className="bg-black min-h-screen">
      <Header />
      
      <main className="pt-32 pb-16">
        <motion.div 
          initial="hidden"
          animate="visible"
          variants={pageContainerVariants}
          className="container mx-auto px-4"
        >
          <motion.div variants={pageItemVariants} className="mb-8 flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold mb-2">Admin Dashboard</h1>
              <p className="text-gray-400">Monitor and manage your platform's performance</p>
            </div>
            <Button variant="outline" className="flex items-center">
              <Download className="mr-2 h-4 w-4" />
              Export Report
            </Button>
          </motion.div>
          
          {/* Key Metrics */}
          <motion.div variants={pageItemVariants} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card className="bg-slate-900/50 backdrop-blur-sm border-slate-800">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-400">Active Users</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div className="text-2xl font-bold">{activeUsers.toLocaleString()}</div>
                  <div className="p-2 bg-green-500/10 rounded-full">
                    <Users className="h-5 w-5 text-green-500" />
                  </div>
                </div>
                <div className="mt-2 flex items-center text-sm text-green-500">
                  <ArrowUpRight className="mr-1 h-3 w-3" />
                  <span>12% from last month</span>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-slate-900/50 backdrop-blur-sm border-slate-800">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-400">Transactions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div className="text-2xl font-bold">{totalTransactions.toLocaleString()}</div>
                  <div className="p-2 bg-blue-500/10 rounded-full">
                    <CreditCard className="h-5 w-5 text-blue-500" />
                  </div>
                </div>
                <div className="mt-2 flex items-center text-sm text-blue-500">
                  <ArrowUpRight className="mr-1 h-3 w-3" />
                  <span>8% from last month</span>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-slate-900/50 backdrop-blur-sm border-slate-800">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-400">Reconciled Volume</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div className="text-2xl font-bold">₹{(totalVolume / 1000000).toFixed(1)}M</div>
                  <div className="p-2 bg-purple-500/10 rounded-full">
                    <CheckCircle className="h-5 w-5 text-purple-500" />
                  </div>
                </div>
                <div className="mt-2 flex items-center text-sm text-purple-500">
                  <ArrowUpRight className="mr-1 h-3 w-3" />
                  <span>15% from last month</span>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-slate-900/50 backdrop-blur-sm border-slate-800">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-400">Dispute Rate</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div className="text-2xl font-bold">{disputeRate}%</div>
                  <div className="p-2 bg-amber-500/10 rounded-full">
                    <AlertTriangle className="h-5 w-5 text-amber-500" />
                  </div>
                </div>
                <div className="mt-2 flex items-center text-sm text-green-500">
                  <ArrowUpRight className="mr-1 h-3 w-3 rotate-180" />
                  <span>0.5% from last month</span>
                </div>
              </CardContent>
            </Card>
          </motion.div>
          
          {/* Charts and Data */}
          <motion.div variants={pageItemVariants} className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <Card className="bg-slate-900/50 backdrop-blur-sm border-slate-800">
              <CardHeader>
                <CardTitle>User Growth</CardTitle>
                <CardDescription>Monthly active users</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={userStats}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                      <XAxis dataKey="month" stroke="#9CA3AF" />
                      <YAxis stroke="#9CA3AF" />
                      <Tooltip 
                        contentStyle={{ backgroundColor: '#1F2937', borderColor: '#374151' }}
                        itemStyle={{ color: '#F9FAFB' }}
                        labelStyle={{ color: '#F9FAFB' }}
                      />
                      <Bar dataKey="users" fill="#8884d8" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-slate-900/50 backdrop-blur-sm border-slate-800">
              <CardHeader>
                <CardTitle>Transaction Volume</CardTitle>
                <CardDescription>Monthly transaction volume in INR</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={transactionVolume}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                      <XAxis dataKey="month" stroke="#9CA3AF" />
                      <YAxis stroke="#9CA3AF" tickFormatter={(value) => `₹${value / 1000000}M`} />
                      <Tooltip 
                        contentStyle={{ backgroundColor: '#1F2937', borderColor: '#374151' }}
                        itemStyle={{ color: '#F9FAFB' }}
                        labelStyle={{ color: '#F9FAFB' }}
                        formatter={(value) => [`₹${(value as number / 1000000).toFixed(1)}M`, 'Volume']}
                      />
                      <Line type="monotone" dataKey="volume" stroke="#10B981" strokeWidth={2} dot={{ r: 4 }} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </motion.div>
          
          {/* Additional Data */}
          <motion.div variants={pageItemVariants} className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
            <Card className="bg-slate-900/50 backdrop-blur-sm border-slate-800">
              <CardHeader>
                <CardTitle>Dispute Status</CardTitle>
                <CardDescription>Current dispute resolution status</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-64 flex items-center justify-center">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={disputeData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {disputeData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip 
                        contentStyle={{ backgroundColor: '#1F2937', borderColor: '#374151' }}
                        itemStyle={{ color: '#F9FAFB' }}
                        labelStyle={{ color: '#F9FAFB' }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-slate-900/50 backdrop-blur-sm border-slate-800 lg:col-span-2">
              <CardHeader>
                <CardTitle>Integration Status</CardTitle>
                <CardDescription>Status of connected payment processors and banks</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {integrationStatus.map((integration) => (
                    <div key={integration.name} className="flex items-center justify-between pb-2 border-b border-slate-800">
                      <div className="flex items-center">
                        <div className={`w-2 h-2 rounded-full mr-3 ${
                          integration.status === 'active' ? 'bg-green-500' : 
                          integration.status === 'maintenance' ? 'bg-amber-500' : 'bg-red-500'
                        }`}></div>
                        <div>
                          <p className="font-medium">{integration.name}</p>
                          <p className="text-sm text-gray-400">{integration.users} users | {integration.volume}</p>
                        </div>
                      </div>
                      <div className="text-sm">
                        <span className={`px-2 py-1 rounded-full ${
                          integration.status === 'active' ? 'bg-green-500/10 text-green-500' : 
                          integration.status === 'maintenance' ? 'bg-amber-500/10 text-amber-500' : 'bg-red-500/10 text-red-500'
                        }`}>
                          {integration.status === 'active' ? 'Active' : 
                           integration.status === 'maintenance' ? 'Maintenance' : 'Down'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
          
          {/* Admin Controls */}
          <motion.div variants={pageItemVariants}>
            <Tabs defaultValue="features" className="space-y-4">
              <TabsList className="bg-slate-800/50 border border-slate-700">
                <TabsTrigger value="features">Feature Management</TabsTrigger>
                <TabsTrigger value="audit">Audit Logs</TabsTrigger>
              </TabsList>
              
              <TabsContent value="features" className="mt-0">
                <Card className="bg-slate-900/50 backdrop-blur-sm border-slate-800">
                  <CardHeader>
                    <CardTitle>Feature Management</CardTitle>
                    <CardDescription>Control platform features and capabilities</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {isLoading ? (
                      <div className="flex justify-center items-center py-8">
                        <Loader2 className="h-8 w-8 animate-spin text-indigo-500" />
                      </div>
                    ) : error ? (
                      <Alert variant="destructive" className="mb-4 bg-red-900/50 border-red-800">
                        <AlertCircle className="h-4 w-4" />
                        <AlertDescription>{error}</AlertDescription>
                      </Alert>
                    ) : (
                      <div className="space-y-4">
                        {featureFlags.map((feature) => (
                          <div key={feature.id} className="flex items-center justify-between pb-4 border-b border-slate-800">
                            <div>
                              <h3 className="font-medium">{feature.displayName}</h3>
                              <p className="text-sm text-gray-400">{feature.description}</p>
                            </div>
                            <div className="flex items-center space-x-2">
                              <span className={feature.enabled ? "text-green-500 text-sm" : "text-slate-400 text-sm"}>
                                {feature.enabled ? "Enabled" : "Disabled"}
                              </span>
                              <div className="flex items-center">
                                <Switch
                                  checked={feature.enabled}
                                  onCheckedChange={(checked) => handleFeatureToggle(feature.id, checked)}
                                  disabled={isUpdatingFeature}
                                  className={`${feature.enabled ? "bg-green-500" : "bg-slate-700"}`}
                                />
                              </div>
                            </div>
                          </div>
                        ))}
                        
                        {featureFlags.length === 0 && !isLoading && (
                          <div className="text-center py-4">
                            <p className="text-gray-400">No feature flags found</p>
                          </div>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="audit" className="mt-0">
                <Card className="bg-slate-900/50 backdrop-blur-sm border-slate-800">
                  <CardHeader>
                    <CardTitle>Audit Logs</CardTitle>
                    <CardDescription>System activity and security logs</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {isLoading ? (
                      <div className="flex justify-center items-center py-8">
                        <Loader2 className="h-8 w-8 animate-spin text-indigo-500" />
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {auditLogs.length > 0 ? (
                          auditLogs.map((log) => (
                            <div key={log.id} className="flex items-center justify-between pb-4 border-b border-slate-800">
                              <div className="flex items-center">
                                {log.action.includes('login') && <Shield className="h-5 w-5 text-blue-500 mr-3" />}
                                {log.action.includes('feature') && <Settings className="h-5 w-5 text-purple-500 mr-3" />}
                                {log.action.includes('backup') && <Database className="h-5 w-5 text-green-500 mr-3" />}
                                {log.action.includes('user') && <Users className="h-5 w-5 text-amber-500 mr-3" />}
                                {log.action.includes('failed') && <AlertTriangle className="h-5 w-5 text-red-500 mr-3" />}
                                <div>
                                  <p className="font-medium">{log.action.replace('_', ' ')}</p>
                                  <p className="text-sm text-gray-400">
                                    {log.resourceType}: {log.resourceId}
                                  </p>
                                </div>
                              </div>
                              <div className="text-sm text-gray-500">{formatDate(log.timestamp)}</div>
                            </div>
                          ))
                        ) : (
                          <div className="text-center py-4">
                            <p className="text-gray-400">No audit logs found</p>
                          </div>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </motion.div>
        </motion.div>
      </main>
      
      <Footer />
    </div>
  );
}
