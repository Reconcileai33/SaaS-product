import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar } from '@/components/ui/avatar';
import { Input } from '@/components/ui/input';
import { MessageCircle, X, Send, Loader2, ExternalLink } from 'lucide-react';
import api, { ChatMessage as ApiChatMessage, ChatSession } from '@/lib/api';

// Types for the chatbot
interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: Date;
}

interface SuggestedAction {
  type: 'view_transaction' | 'create_dispute' | 'contact_support' | 'run_reconciliation' | 'view_documentation';
  label: string;
  payload: any;
}

interface ChatbotResponse {
  message: string;
  suggestedActions?: SuggestedAction[];
  relatedTransactions?: any[];
  confidence: number;
}

export default function Chatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // State for chat session
  const [sessionId, setSessionId] = useState<string | null>(null);
  
  // Load chat history on component mount
  useEffect(() => {
    const loadChatHistory = async () => {
      try {
        // Create a new chat session if none exists
        if (!sessionId) {
          const session = await api.supportChatbot.createChatSession();
          if (session.id) {
            setSessionId(session.id);
          }
          
          // Convert API messages to UI messages
          const uiMessages = session.messages.map(msg => ({
            id: msg.id || Date.now().toString(),
            role: (msg.type === 'user' ? 'user' : 'assistant') as 'user' | 'assistant' | 'system',
            content: msg.content,
            timestamp: new Date(msg.timestamp)
          }));
          
          if (uiMessages.length > 0) {
            setMessages(uiMessages);
          } else {
            // Set default welcome message if no history
            setMessages([
              {
                id: '1',
                role: 'assistant',
                content: 'Hi there! I\'m your AI assistant. How can I help you with reconciliation or dispute resolution today?',
                timestamp: new Date()
              }
            ]);
          }
        } else {
          // Get existing session
          const session = await api.supportChatbot.getChatSession(sessionId);
          
          // Convert API messages to UI messages
          const uiMessages = session.messages.map(msg => ({
            id: msg.id || Date.now().toString(),
            role: (msg.type === 'user' ? 'user' : 'assistant') as 'user' | 'assistant' | 'system',
            content: msg.content,
            timestamp: new Date(msg.timestamp)
          }));
          
          if (uiMessages.length > 0) {
            setMessages(uiMessages);
          }
        }
      } catch (error) {
        console.error('Error loading chat history:', error);
        // Set default welcome message if API fails
        setMessages([
          {
            id: '1',
            role: 'assistant',
            content: 'Hi there! I\'m your AI assistant. How can I help you with reconciliation or dispute resolution today?',
            timestamp: new Date()
          }
        ]);
      }
    };
    
    if (isOpen) {
      loadChatHistory();
    }
  }, [isOpen, sessionId]);
  
  // Scroll to bottom of messages
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);
  
  // Helper function to handle chatbot response
  const handleChatbotResponse = (response: ChatbotResponse) => {
    // Add assistant message
    const assistantMessage: ChatMessage = {
      id: (Date.now() + 1).toString(),
      role: 'assistant',
      content: response.message,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, assistantMessage]);
    
    // Add system message with suggested actions if available
    if (response.suggestedActions && response.suggestedActions.length > 0) {
      const systemMessage: ChatMessage = {
        id: (Date.now() + 2).toString(),
        role: 'system',
        content: JSON.stringify(response.suggestedActions),
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, systemMessage]);
    }
  };
  
  const handleSendMessage = async () => {
    if (!inputValue.trim() || !sessionId) return;
    
    // Add user message to UI immediately for better UX
    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: inputValue,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsLoading(true);
    
    try {
      // Call our support chatbot API
      const response = await api.supportChatbot.sendMessage(sessionId, inputValue.trim());
      
      // Add bot message from API response
      const botMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response.botMessage.content,
        timestamp: new Date(response.botMessage.timestamp)
      };
      
      setMessages(prev => [...prev, botMessage]);
      
      // If we have metadata with suggested actions, add them as a system message
      if (response.botMessage.metadata && response.botMessage.metadata.intent) {
        let suggestedActions: SuggestedAction[] = [];
        
        // Generate suggested actions based on intent
        switch (response.botMessage.metadata.intent) {
          case 'RECONCILIATION':
            suggestedActions = [
              {
                type: 'run_reconciliation',
                label: 'Run reconciliation now',
                payload: { userId: '123' }
              }
            ];
            break;
          case 'BANK_CONNECTION':
            suggestedActions = [
              {
                type: 'view_documentation',
                label: 'View connection guide',
                payload: { section: 'bank-connections' }
              }
            ];
            break;
          case 'HELP':
            suggestedActions = [
              {
                type: 'view_documentation',
                label: 'View user guide',
                payload: { section: 'getting-started' }
              },
              {
                type: 'contact_support',
                label: 'Contact support team',
                payload: { issueType: 'general' }
              }
            ];
            break;
        }
        
        // Add system message with suggested actions if available
        if (suggestedActions.length > 0) {
          const systemMessage: ChatMessage = {
            id: (Date.now() + 2).toString(),
            role: 'system',
            content: JSON.stringify(suggestedActions),
            timestamp: new Date()
          };
          
          setMessages(prev => [...prev, systemMessage]);
        }
      }
    } catch (error) {
      console.error('Error sending message:', error);
      
      // Add error message
      const errorMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: 'Sorry, I encountered an error processing your request. Please try again later.',
        timestamp: new Date()
      };
      
    }
  };

  if (isOpen) {
    loadChatHistory();
  }
}, [isOpen, sessionId]);

// Scroll to bottom of messages
useEffect(() => {
  if (messagesEndRef.current) {
    messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
  }
}, [messages]);

// Helper function to handle chatbot response
const handleChatbotResponse = (response: ChatbotResponse) => {
  // Add assistant message
  const assistantMessage: ChatMessage = {
    id: (Date.now() + 1).toString(),
    role: 'assistant',
    content: response.message,
    timestamp: new Date(),
  };

  setMessages((prev) => [...prev, assistantMessage]);

  // Add system message with suggested actions if available
  if (response.suggestedActions && response.suggestedActions.length > 0) {
  };
  
  const handleActionClick = (action: SuggestedAction) => {
    // Handle suggested actions
    console.log('Action clicked:', action);
    
    // Add a message acknowledging the action
    const systemMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'system',
      content: `Executing action: ${action.label}`,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, systemMessage]);
  };
  
  return (
    <>
      {/* Chatbot toggle button */}
      <motion.button
        className="fixed bottom-6 right-6 w-12 h-12 rounded-full bg-gradient-to-r from-violet-600 to-indigo-600 flex items-center justify-center shadow-lg z-50"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => setIsOpen(!isOpen)}
      >
        {isOpen ? (
          <X className="h-5 w-5 text-white" />
        ) : (
          <MessageCircle className="h-5 w-5 text-white" />
        )}
      </motion.button>
      
      {/* Chatbot panel */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            className="fixed bottom-20 right-6 w-80 sm:w-96 z-50"
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 50, scale: 0.9 }}
            transition={{ duration: 0.2 }}
          >
            <Card className="border-slate-800 overflow-hidden shadow-xl">
              <div className="bg-gradient-to-r from-violet-600 to-indigo-600 p-3 flex items-center justify-between">
                <div className="flex items-center">
                  <Avatar className="h-8 w-8 mr-2 bg-white/10">
                    <MessageCircle className="h-4 w-4 text-white" />
                  </Avatar>
                  <h3 className="font-medium text-white">AI Assistant</h3>
                </div>
                <Button variant="ghost" size="icon" className="text-white hover:bg-white/10" onClick={() => setIsOpen(false)}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
              
              <div className="h-80 overflow-y-auto p-3 bg-slate-950 space-y-4">
                {messages.map((message) => (
                  <div key={message.id} className={`flex ${message.role === 'user' ? 'justify-end' : ''}`}>
                    {message.role === 'user' ? (
                      <div className="bg-indigo-600 text-white rounded-lg py-2 px-3 max-w-[80%]">
                        <p>{message.content}</p>
                        <div className="mt-1">
                          <span className="text-xs text-white/70">
                            {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                      </div>
                    ) : message.role === 'assistant' ? (
                      <div className="flex">
                        <div className="bg-slate-800 text-white rounded-lg py-2 px-3 max-w-[80%]">
                          <p>{message.content}</p>
                          <div className="mt-1">
                            <span className="text-xs text-white/70">
                              {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </span>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="flex justify-center my-2">
                        {/* System message with suggested actions */}
                        {message.content.startsWith('[') ? (
                          <div className="flex flex-wrap gap-2 justify-center">
                            {JSON.parse(message.content).map((action: SuggestedAction, index: number) => (
                              <Button
                                key={index}
                                variant="outline"
                                size="sm"
                                className="bg-slate-800 border-slate-700 hover:bg-slate-700 text-white"
                                onClick={() => handleActionClick(action)}
                              >
                                {action.type === 'view_documentation' && <ExternalLink className="h-3 w-3 mr-1" />}
                                {action.label}
                              </Button>
                            ))}
                          </div>
                        ) : (
                          <div className="bg-amber-500/10 text-amber-500 text-xs rounded-lg py-1 px-2">
                            {message.content}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                ))}
                
                {isLoading && (
                  <div className="flex mb-4">
                    <div className="bg-slate-800 text-white rounded-lg py-2 px-3">
                      <div className="flex items-center">
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        <p>Thinking...</p>
                      </div>
                    </div>
                  </div>
                )}
                
                <div ref={messagesEndRef} />
              </div>
              
              <CardContent className="p-3 border-t border-slate-800 bg-slate-900/70">
                <div className="flex gap-2">
                  <Input
                    placeholder="Type your message..."
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    onKeyDown={handleKeyDown}
                    className="bg-slate-800 border-slate-700 text-white"
                    disabled={isLoading}
                  />
                  <Button 
                    variant="default" 
                    size="icon"
                    onClick={handleSendMessage}
                    disabled={isLoading || !inputValue.trim()}
                    className="bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700"
                  >
                    {isLoading ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Send className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
