/**
 * Bank Connection Callback Page
 * 
 * This page handles the OAuth callback from bank connections.
 */

import React, { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { AlertCircle, CheckCircle, Loader2 } from "lucide-react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { bankIntegrationApi } from "@/lib/bankIntegrationApi";

export default function BankCallbackPage() {
  const [, navigate] = useLocation();
  const [status, setStatus] = useState<"loading" | "success" | "error">("loading");
  const [message, setMessage] = useState<string>("");
  
  useEffect(() => {
    const handleCallback = async () => {
      try {
        // Get the query parameters from the URL
        const urlParams = new URLSearchParams(window.location.search);
        const code = urlParams.get("code");
        const state = urlParams.get("state");
        const error = urlParams.get("error");
        
        // Check if there was an error in the OAuth process
        if (error) {
          setStatus("error");
          setMessage(`Authentication failed: ${error}`);
          return;
        }
        
        // Check if we have the required parameters
        if (!code || !state) {
          setStatus("error");
          setMessage("Missing required parameters for bank connection.");
          return;
        }
        
        // Process the callback with our backend
        const response = await fetch("/api/bank-connections/callback", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${localStorage.getItem("token")}`
          },
          body: JSON.stringify({ code, state })
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw new Error(data.message || "Failed to complete bank connection");
        }
        
        // Connection successful
        setStatus("success");
        setMessage("Bank account connected successfully!");
        
        // Automatically redirect after a short delay
        setTimeout(() => {
          navigate("/bank-connections");
        }, 3000);
      } catch (error) {
        console.error("Bank connection callback error:", error);
        setStatus("error");
        setMessage(error instanceof Error ? error.message : "An unknown error occurred");
      }
    };
    
    handleCallback();
  }, [navigate]);
  
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-900 to-gray-950 p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-xl flex items-center">
            {status === "loading" && (
              <>
                <Loader2 className="h-5 w-5 mr-2 animate-spin text-primary" />
                Connecting Bank Account
              </>
            )}
            {status === "success" && (
              <>
                <CheckCircle className="h-5 w-5 mr-2 text-green-500" />
                Connection Successful
              </>
            )}
            {status === "error" && (
              <>
                <AlertCircle className="h-5 w-5 mr-2 text-red-500" />
                Connection Failed
              </>
            )}
          </CardTitle>
          <CardDescription>
            {status === "loading" 
              ? "Please wait while we establish a secure connection to your bank account..."
              : message
            }
          </CardDescription>
        </CardHeader>
        
        <CardContent>
          <div className="flex justify-center">
            {status === "loading" && (
              <div className="w-16 h-16 border-4 border-primary/30 border-t-primary rounded-full animate-spin" />
            )}
          </div>
        </CardContent>
        
        <CardFooter className="flex justify-end">
          <Button 
            onClick={() => navigate("/bank-connections")}
            variant={status === "loading" ? "outline" : "default"}
            disabled={status === "loading"}
          >
            {status === "loading" ? "Please wait..." : "Go to Bank Connections"}
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}
