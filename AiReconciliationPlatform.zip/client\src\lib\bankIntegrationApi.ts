/**
 * Bank Integration API Service
 * 
 * This module provides functions for interacting with bank integration endpoints.
 */

import { apiFetch } from './api';

// Types
export enum SSOProvider {
  RAZORPAYX = 'razorpayx',
  RBL = 'rbl',
  HDFC = 'hdfc',
  ICICI = 'icici',
  CASTLER = 'castler',
  STRIPE = 'stripe',
  PAYPAL = 'paypal'
}

export interface BankIntegration {
  id: string;
  provider: SSOProvider;
  name: string;
  displayName: string;
  description: string;
  status: 'active' | 'maintenance' | 'deprecated' | 'disabled';
  features: {
    accountInfo: boolean;
    transactions: boolean;
    payments: boolean;
    beneficiaries: boolean;
    statements: boolean;
  };
  apiVersion: string;
  documentationUrl: string;
  supportEmail: string;
  createdAt: string;
  updatedAt: string;
}

export interface BankConnection {
  id: string;
  userId: string;
  provider: SSOProvider;
  status: 'active' | 'expired' | 'revoked' | 'error';
  accountId: string;
  accountName: string;
  accountType: string;
  accessToken: string;
  refreshToken: string;
  expiresAt: string;
  lastRefreshed: string;
  metadata: Record<string, any>;
  createdAt: string;
  updatedAt: string;
}

export interface ConnectionStatus {
  provider: SSOProvider;
  status: 'operational' | 'degraded' | 'outage' | 'maintenance';
  lastChecked: string;
  responseTime?: number;
  message?: string;
}

// Bank Integration API service
export const bankIntegrationApi = {
  /**
   * Get all available bank integrations
   */
  async getIntegrations(): Promise<BankIntegration[]> {
    const response = await apiFetch<{ integrations: BankIntegration[] }>('/bank-integrations');
    return response.integrations;
  },
  
  /**
   * Get a specific bank integration by provider
   */
  async getIntegrationByProvider(provider: SSOProvider): Promise<BankIntegration> {
    const response = await apiFetch<{ integration: BankIntegration }>(`/bank-integrations/${provider}`);
    return response.integration;
  },
  
  /**
   * Get user's bank connections
   */
  async getUserConnections(): Promise<BankConnection[]> {
    const response = await apiFetch<{ connections: BankConnection[] }>('/bank-connections');
    return response.connections;
  },
  
  /**
   * Initiate a new bank connection
   */
  async initiateConnection(provider: SSOProvider): Promise<{ redirectUrl: string }> {
    const response = await apiFetch<{ redirectUrl: string }>('/bank-connections/initiate', {
      method: 'POST',
      body: JSON.stringify({ provider })
    });
    return response;
  },
  
  /**
   * Disconnect a bank connection
   */
  async disconnectConnection(connectionId: string): Promise<{ success: boolean }> {
    const response = await apiFetch<{ success: boolean }>(`/bank-connections/${connectionId}`, {
      method: 'DELETE'
    });
    return response;
  },
  
  /**
   * Refresh a bank connection token
   */
  async refreshConnection(connectionId: string): Promise<BankConnection> {
    const response = await apiFetch<{ connection: BankConnection }>(`/bank-connections/${connectionId}/refresh`, {
      method: 'POST'
    });
    return response.connection;
  },
  
  /**
   * Get the status of all bank integrations
   */
  async getIntegrationStatuses(): Promise<ConnectionStatus[]> {
    const response = await apiFetch<{ statuses: ConnectionStatus[] }>('/bank-integrations/status');
    return response.statuses;
  },
  
  /**
   * Get transactions for a specific bank connection
   */
  async getConnectionTransactions(connectionId: string, params?: {
    startDate?: string;
    endDate?: string;
    limit?: number;
    offset?: number;
  }): Promise<any[]> {
    let url = `/bank-connections/${connectionId}/transactions`;
    
    if (params) {
      const queryParams = new URLSearchParams();
      if (params.startDate) queryParams.append('startDate', params.startDate);
      if (params.endDate) queryParams.append('endDate', params.endDate);
      if (params.limit) queryParams.append('limit', params.limit.toString());
      if (params.offset) queryParams.append('offset', params.offset.toString());
      
      if (queryParams.toString()) {
        url += `?${queryParams.toString()}`;
      }
    }
    
    const response = await apiFetch<{ transactions: any[] }>(url);
    return response.transactions;
  }
};
