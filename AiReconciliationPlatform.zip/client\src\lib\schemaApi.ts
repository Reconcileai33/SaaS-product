/**
 * Schema API Service
 * 
 * This module provides functions for interacting with the schema management API endpoints.
 */

import { apiFetch } from './api';

// Interface for schema field
export interface SchemaField {
  name: string;
  type: 'string' | 'number' | 'boolean' | 'date' | 'object' | 'array';
  isRequired: boolean;
  defaultValue?: any;
  validationRules?: {
    min?: number;
    max?: number;
    pattern?: string;
    enum?: any[];
  };
  nestedFields?: SchemaField[];
}

// Interface for schema template
export interface SchemaTemplate {
  id: string;
  name: string;
  description: string;
  fields: SchemaField[];
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

// Interface for user schema
export interface UserSchema {
  id: string;
  userId: string;
  companyId?: string;
  name: string;
  description: string;
  collectionName: string;
  fields: SchemaField[];
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

// Schema API service
export const schemaApi = {
  /**
   * Get all schema templates
   */
  async getSchemaTemplates() {
    try {
      const response = await apiFetch<{templates: SchemaTemplate[]}>('/schema-management/templates');
      return response.templates;
    } catch (error) {
      console.error('Error fetching schema templates:', error);
      throw new Error('Failed to fetch schema templates');
    }
  },

  /**
   * Get schema template by ID
   */
  async getSchemaTemplateById(id: string) {
    try {
      const response = await apiFetch<{template: SchemaTemplate}>(`/schema-management/templates/${id}`);
      return response.template;
    } catch (error) {
      console.error(`Error fetching schema template ${id}:`, error);
      throw new Error('Failed to fetch schema template');
    }
  },

  /**
   * Get all user schemas
   */
  async getUserSchemas() {
    try {
      const response = await apiFetch<{schemas: UserSchema[]}>('/schema-management/user');
      return response.schemas;
    } catch (error) {
      console.error('Error fetching user schemas:', error);
      throw new Error('Failed to fetch user schemas');
    }
  },

  /**
   * Get user schema by ID
   */
  async getUserSchemaById(id: string) {
    try {
      const response = await apiFetch<{schema: UserSchema}>(`/schema-management/user/${id}`);
      return response.schema;
    } catch (error) {
      console.error(`Error fetching user schema ${id}:`, error);
      throw new Error('Failed to fetch user schema');
    }
  },

  /**
   * Create a new user schema from template
   */
  async createUserSchema(templateId: string, name: string, description: string) {
    try {
      const response = await apiFetch<{schema: UserSchema}>('/schema-management/user', {
        method: 'POST',
        body: JSON.stringify({
          templateId,
          name,
          description
        })
      });
      return response.schema;
    } catch (error) {
      console.error('Error creating user schema:', error);
      throw new Error('Failed to create user schema');
    }
  },

  /**
   * Update a user schema
   */
  async updateUserSchema(id: string, data: Partial<UserSchema>) {
    try {
      const response = await apiFetch<{schema: UserSchema}>(`/schema-management/user/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data)
      });
      return response.schema;
    } catch (error) {
      console.error(`Error updating user schema ${id}:`, error);
      throw new Error('Failed to update user schema');
    }
  },

  /**
   * Delete a user schema
   */
  async deleteUserSchema(id: string) {
    try {
      const response = await apiFetch<{success: boolean}>(`/schema-management/user/${id}`, {
        method: 'DELETE'
      });
      return response.success;
    } catch (error) {
      console.error(`Error deleting user schema ${id}:`, error);
      throw new Error('Failed to delete user schema');
    }
  },

  /**
   * Generate a schema from sample data
   */
  async generateSchemaFromData(name: string, description: string, sampleData: any[]) {
    try {
      const response = await apiFetch<{schema: UserSchema}>('/schema-management/generate-from-data', {
        method: 'POST',
        body: JSON.stringify({
          name,
          description,
          sampleData
        })
      });
      return response.schema;
    } catch (error) {
      console.error('Error generating schema from data:', error);
      throw new Error('Failed to generate schema from data');
    }
  },

  /**
   * Analyze a schema and suggest improvements
   */
  async analyzeSchema(schemaId: string, sampleData: any[]) {
    try {
      const response = await apiFetch<{recommendations: any}>('/schema-management/analyze', {
        method: 'POST',
        body: JSON.stringify({
          schemaId,
          sampleData
        })
      });
      return response.recommendations;
    } catch (error) {
      console.error('Error analyzing schema:', error);
      throw new Error('Failed to analyze schema');
    }
  }
};
