/**
 * Constants used throughout the application
 */

// Base API URL - in production, this would be configured based on environment
export const API_BASE_URL = '/api';
