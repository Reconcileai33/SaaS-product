/**
 * Admin Audit Trail Page
 * 
 * This page displays the audit trail logs for admin users.
 */

import React, { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { adminApi, AuditLog } from "@/lib/adminApi";
import { authApi } from "@/lib/api";
import { 
  AlertCircle, 
  AlertTriangle, 
  CheckCircle, 
  ChevronLeft, 
  ChevronRight, 
  Download, 
  Filter, 
  Info, 
  Search, 
  Shield 
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
// Import AdminLayout component
import { AdminLayout } from "../../components/layouts/AdminLayout";

// Severity icon mapping
const SeverityIcon = ({ severity }: { severity: string }) => {
  switch (severity) {
    case 'info':
      return <Info className="h-5 w-5 text-blue-500" />;
    case 'warning':
      return <AlertTriangle className="h-5 w-5 text-amber-500" />;
    case 'error':
      return <AlertCircle className="h-5 w-5 text-red-500" />;
    case 'critical':
      return <Shield className="h-5 w-5 text-purple-500" />;
    default:
      return <Info className="h-5 w-5 text-blue-500" />;
  }
};

// Action color mapping
const getActionColor = (action: string) => {
  switch (action) {
    case 'create':
      return 'text-green-500';
    case 'update':
      return 'text-blue-500';
    case 'delete':
      return 'text-red-500';
    case 'login':
      return 'text-purple-500';
    case 'logout':
      return 'text-gray-500';
    default:
      return 'text-gray-300';
  }
};

export default function AuditTrailPage() {
  const [, navigate] = useLocation();
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(20);
  const [filters, setFilters] = useState<Record<string, string>>({});
  const [searchTerm, setSearchTerm] = useState('');
  
  // Check if admin is authenticated
  useEffect(() => {
    if (!authApi.isAdminAuthenticated()) {
      navigate('/admin/login');
    }
  }, [navigate]);
  
  // Fetch audit logs
  const { 
    data: auditData,
    isLoading,
    error,
    refetch
  } = useQuery({
    queryKey: ['auditLogs', page, limit, filters],
    queryFn: () => adminApi.getAuditLogs(page, limit, filters),
    enabled: authApi.isAdminAuthenticated()
  });
  
  // Handle filter change
  const handleFilterChange = (key: string, value: string) => {
    setFilters(prev => ({
      ...prev,
      [key]: value
    }));
    setPage(1); // Reset to first page when filters change
  };
  
  // Handle search
  const handleSearch = () => {
    if (searchTerm.trim()) {
      setFilters(prev => ({
        ...prev,
        details: searchTerm.trim()
      }));
    } else {
      const newFilters = { ...filters };
      delete newFilters.details;
      setFilters(newFilters);
    }
    setPage(1); // Reset to first page when search changes
  };
  
  // Format date for display
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    }).format(date);
  };
  
  // Export audit logs as CSV
  const exportAuditLogs = () => {
    if (!auditData || !auditData.logs.length) return;
    
    const headers = ['Timestamp', 'User ID', 'User Type', 'Action', 'Resource Type', 'Resource ID', 'Details', 'Severity'];
    const csvRows = [
      headers.join(','),
      ...auditData.logs.map(log => [
        new Date(log.timestamp).toISOString(),
        log.userId,
        log.userType,
        log.action,
        log.resourceType,
        log.resourceId || '',
        `"${log.details.replace(/"/g, '""')}"`,
        log.severity
      ].join(','))
    ];
    
    const csvContent = csvRows.join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `audit-logs-${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  
  return (
    <AdminLayout>
      <div className="container mx-auto py-6 space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold">Audit Trail</h1>
          <Button 
            variant="outline" 
            onClick={exportAuditLogs}
            disabled={!auditData || !auditData.logs.length}
          >
            <Download className="h-4 w-4 mr-2" />
            Export CSV
          </Button>
        </div>
        
        {/* Filters */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="flex space-x-2">
            <Input
              placeholder="Search details..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
            />
            <Button variant="secondary" onClick={handleSearch}>
              <Search className="h-4 w-4" />
            </Button>
          </div>
          
          <Select 
            value={filters.action || ''} 
            onValueChange={(value) => handleFilterChange('action', value)}
          >
            <SelectTrigger>
              <SelectValue placeholder="Action" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">All Actions</SelectItem>
              <SelectItem value="create">Create</SelectItem>
              <SelectItem value="read">Read</SelectItem>
              <SelectItem value="update">Update</SelectItem>
              <SelectItem value="delete">Delete</SelectItem>
              <SelectItem value="login">Login</SelectItem>
              <SelectItem value="logout">Logout</SelectItem>
              <SelectItem value="export">Export</SelectItem>
              <SelectItem value="import">Import</SelectItem>
              <SelectItem value="reconcile">Reconcile</SelectItem>
            </SelectContent>
          </Select>
          
          <Select 
            value={filters.resourceType || ''} 
            onValueChange={(value) => handleFilterChange('resourceType', value)}
          >
            <SelectTrigger>
              <SelectValue placeholder="Resource Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">All Resources</SelectItem>
              <SelectItem value="user">User</SelectItem>
              <SelectItem value="transaction">Transaction</SelectItem>
              <SelectItem value="bank_connection">Bank Connection</SelectItem>
              <SelectItem value="schema">Schema</SelectItem>
              <SelectItem value="reconciliation">Reconciliation</SelectItem>
              <SelectItem value="feature_flag">Feature Flag</SelectItem>
              <SelectItem value="system">System</SelectItem>
            </SelectContent>
          </Select>
          
          <Select 
            value={filters.severity || ''} 
            onValueChange={(value) => handleFilterChange('severity', value)}
          >
            <SelectTrigger>
              <SelectValue placeholder="Severity" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">All Severities</SelectItem>
              <SelectItem value="info">Info</SelectItem>
              <SelectItem value="warning">Warning</SelectItem>
              <SelectItem value="error">Error</SelectItem>
              <SelectItem value="critical">Critical</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        {/* Audit Logs Table */}
        <div className="bg-gray-900/50 backdrop-blur-sm border border-gray-800 rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-gray-900/70">
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Timestamp</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">User</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Action</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Resource</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Details</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Severity</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-800">
                {isLoading ? (
                  // Loading skeletons
                  Array.from({ length: 5 }).map((_, i) => (
                    <tr key={`skeleton-${i}`}>
                      <td className="px-4 py-3"><Skeleton className="h-4 w-32" /></td>
                      <td className="px-4 py-3"><Skeleton className="h-4 w-24" /></td>
                      <td className="px-4 py-3"><Skeleton className="h-4 w-16" /></td>
                      <td className="px-4 py-3"><Skeleton className="h-4 w-24" /></td>
                      <td className="px-4 py-3"><Skeleton className="h-4 w-48" /></td>
                      <td className="px-4 py-3"><Skeleton className="h-4 w-16" /></td>
                    </tr>
                  ))
                ) : error ? (
                  <tr>
                    <td colSpan={6} className="px-4 py-6 text-center text-red-500">
                      <AlertCircle className="h-6 w-6 mx-auto mb-2" />
                      Failed to load audit logs
                    </td>
                  </tr>
                ) : auditData?.logs.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="px-4 py-6 text-center text-gray-400">
                      No audit logs found
                    </td>
                  </tr>
                ) : (
                  auditData?.logs.map((log: AuditLog) => (
                    <tr key={log.id} className="hover:bg-gray-800/50">
                      <td className="px-4 py-3 text-sm text-gray-300">
                        {formatDate(log.timestamp)}
                      </td>
                      <td className="px-4 py-3 text-sm">
                        <div className="text-gray-300">{log.userId}</div>
                        <div className="text-xs text-gray-500">{log.userType}</div>
                      </td>
                      <td className="px-4 py-3 text-sm">
                        <span className={`${getActionColor(log.action)} font-medium`}>
                          {log.action}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-sm">
                        <div className="text-gray-300">{log.resourceType}</div>
                        {log.resourceId && (
                          <div className="text-xs text-gray-500">{log.resourceId}</div>
                        )}
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-300">
                        {log.details}
                      </td>
                      <td className="px-4 py-3 text-sm">
                        <div className="flex items-center space-x-1">
                          <SeverityIcon severity={log.severity} />
                          <span className="capitalize">{log.severity}</span>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
          
          {/* Pagination */}
          {auditData && auditData.total > 0 && (
            <div className="flex items-center justify-between px-4 py-3 bg-gray-900/70">
              <div className="text-sm text-gray-400">
                Showing {(page - 1) * limit + 1} to {Math.min(page * limit, auditData.total)} of {auditData.total} entries
              </div>
              <div className="flex space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setPage(p => Math.max(1, p - 1))}
                  disabled={page === 1}
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setPage(p => p + 1)}
                  disabled={page * limit >= auditData.total}
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </AdminLayout>
  );
}
