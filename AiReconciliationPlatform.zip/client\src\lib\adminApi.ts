/**
 * Admin API Service
 * 
 * This module provides functions for interacting with the admin API endpoints.
 */

import { apiFetch } from './api';

// Types
export interface AdminAnalytics {
  users: {
    total: number;
    business: number;
    individual: number;
    admin: number;
    growth: number;
  };
  transactions: {
    total: number;
    volume: number;
    reconciled: number;
    successRate: number;
  };
  disputes: {
    total: number;
    resolved: number;
    pending: number;
    escalated: number;
  };
  connections: {
    total: number;
    active: number;
  };
}

export interface FeatureFlag {
  id: string;
  name: string;
  description: string;
  enabled: boolean;
  userTypes: string[];
  createdAt: string;
  updatedAt: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  userId: string;
  userType: string;
  action: string;
  resourceType: string;
  resourceId?: string;
  details: string;
  severity: 'info' | 'warning' | 'error' | 'critical';
}

export interface AuditLogResponse {
  logs: AuditLog[];
  total: number;
  page: number;
  limit: number;
}

export interface BankIntegration {
  id: string;
  name: string;
  displayName: string;
  status: 'active' | 'maintenance' | 'inactive';
  description: string;
  features: string[];
  createdAt: string;
  updatedAt: string;
}

// Admin API service
export const adminApi = {
  /**
   * Admin login
   */
  async login(email: string, password: string) {
    const response = await apiFetch<{ token: string }>('/admin/login', {
      method: 'POST',
      body: JSON.stringify({ email, password })
    });
    
    if (response.token) {
      localStorage.setItem('adminToken', response.token);
    }
    
    return response;
  },
  
  /**
   * Admin logout
   */
  logout() {
    localStorage.removeItem('adminToken');
  },
  
  /**
   * Get system analytics
   */
  async getAnalytics() {
    const response = await apiFetch<{ analytics: AdminAnalytics }>('/admin/analytics');
    return response.analytics;
  },
  
  /**
   * Get feature flags
   */
  async getFeatureFlags() {
    const response = await apiFetch<{ flags: FeatureFlag[] }>('/admin/feature-flags');
    return response.flags;
  },
  
  /**
   * Update feature flag
   */
  async updateFeatureFlag(id: string, enabled: boolean) {
    const response = await apiFetch<{ flag: FeatureFlag }>(`/admin/feature-flags/${id}`, {
      method: 'PATCH',
      body: JSON.stringify({ enabled })
    });
    return response.flag;
  },
  
  /**
   * Get audit logs
   */
  async getAuditLogs(page = 1, limit = 20, filters?: Record<string, string>) {
    let url = `/admin/audit-logs?page=${page}&limit=${limit}`;
    
    if (filters) {
      Object.entries(filters).forEach(([key, value]) => {
        if (value) {
          url += `&${key}=${encodeURIComponent(value)}`;
        }
      });
    }
    
    const response = await apiFetch<AuditLogResponse>(url);
    return response;
  },
  
  /**
   * Get audit logs for a specific resource
   */
  async getResourceAuditLogs(resourceType: string, resourceId: string, page = 1, limit = 20) {
    const url = `/admin/audit-logs?resourceType=${resourceType}&resourceId=${resourceId}&page=${page}&limit=${limit}`;
    const response = await apiFetch<AuditLogResponse>(url);
    return response;
  },
  
  /**
   * Get audit logs for a specific user
   */
  async getUserAuditLogs(userId: string, page = 1, limit = 20) {
    const url = `/admin/audit-logs?userId=${userId}&page=${page}&limit=${limit}`;
    const response = await apiFetch<AuditLogResponse>(url);
    return response;
  },
  
  /**
   * Get all users
   */
  async getUsers() {
    const response = await apiFetch<{ users: any[] }>('/admin/users');
    return response.users;
  },
  
  /**
   * Get bank integrations
   */
  async getBankIntegrations() {
    const response = await apiFetch<{ integrations: BankIntegration[] }>('/admin/integrations');
    return response.integrations;
  },
  
  /**
   * Update bank integration status
   */
  async updateIntegrationStatus(id: string, status: 'active' | 'maintenance' | 'inactive') {
    const response = await apiFetch<{ integration: BankIntegration }>(`/admin/integrations/${id}`, {
      method: 'PATCH',
      body: JSON.stringify({ status })
    });
    return response.integration;
  }
};
