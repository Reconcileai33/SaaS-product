import { useState } from "react";
import { motion } from "framer-motion";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  AlertCircle,
  Save,
  Server,
  Mail,
  Shield,
  CreditCard,
  Globe,
  FileText,
  Bell
} from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { adminApi } from "@/lib/api";
import { pageContainerVariants } from "@/lib/animations";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";

// Settings form schema
const generalSettingsSchema = z.object({
  siteName: z.string().min(2, "Site name must be at least 2 characters"),
  siteDescription: z.string().min(10, "Description must be at least 10 characters"),
  supportEmail: z.string().email("Please enter a valid email"),
  maintenanceMode: z.boolean().default(false),
  allowNewRegistrations: z.boolean().default(true),
  defaultUserRole: z.enum(["user", "admin"]),
  maxLoginAttempts: z.number().min(1).max(10),
});

const emailSettingsSchema = z.object({
  smtpHost: z.string().min(1, "SMTP host is required"),
  smtpPort: z.number().min(1).max(65535),
  smtpUsername: z.string().min(1, "SMTP username is required"),
  smtpPassword: z.string().min(1, "SMTP password is required"),
  senderEmail: z.string().email("Please enter a valid email"),
  senderName: z.string().min(1, "Sender name is required"),
  enableEmailVerification: z.boolean().default(true),
});

const apiSettingsSchema = z.object({
  apiRateLimit: z.number().min(10).max(1000),
  apiTokenExpiry: z.number().min(1).max(30),
  enableApiLogging: z.boolean().default(true),
  allowCors: z.boolean().default(false),
  corsOrigins: z.string().optional(),
});

type GeneralSettingsFormValues = z.infer<typeof generalSettingsSchema>;
type EmailSettingsFormValues = z.infer<typeof emailSettingsSchema>;
type ApiSettingsFormValues = z.infer<typeof apiSettingsSchema>;

export default function AdminSettings() {
  const [activeTab, setActiveTab] = useState("general");
  const { toast } = useToast();

  // General settings form
  const generalForm = useForm<GeneralSettingsFormValues>({
    resolver: zodResolver(generalSettingsSchema),
    defaultValues: {
      siteName: "Reconcile AI",
      siteDescription: "AI-Powered Reconciliation Platform for businesses and individuals",
      supportEmail: "support@reconcileai.com",
      maintenanceMode: false,
      allowNewRegistrations: true,
      defaultUserRole: "user",
      maxLoginAttempts: 5,
    },
  });

  // Email settings form
  const emailForm = useForm<EmailSettingsFormValues>({
    resolver: zodResolver(emailSettingsSchema),
    defaultValues: {
      smtpHost: "smtp.example.com",
      smtpPort: 587,
      smtpUsername: "notifications@reconcileai.com",
      smtpPassword: "••••••••••••",
      senderEmail: "notifications@reconcileai.com",
      senderName: "Reconcile AI",
      enableEmailVerification: true,
    },
  });

  // API settings form
  const apiForm = useForm<ApiSettingsFormValues>({
    resolver: zodResolver(apiSettingsSchema),
    defaultValues: {
      apiRateLimit: 100,
      apiTokenExpiry: 7,
      enableApiLogging: true,
      allowCors: false,
      corsOrigins: "",
    },
  });

  // Handle general settings submission
  const onGeneralSubmit = async (data: GeneralSettingsFormValues) => {
    try {
      // In a real implementation, we would update via API
      // await adminApi.updateGeneralSettings(data);
      
      console.log("Updating general settings:", data);
      
      toast({
        title: "Settings updated",
        description: "General settings have been updated successfully.",
      });
    } catch (error) {
      console.error("Error updating settings:", error);
      toast({
        title: "Update failed",
        description: "There was an error updating the settings.",
        variant: "destructive",
      });
    }
  };

  // Handle email settings submission
  const onEmailSubmit = async (data: EmailSettingsFormValues) => {
    try {
      // In a real implementation, we would update via API
      // await adminApi.updateEmailSettings(data);
      
      console.log("Updating email settings:", data);
      
      toast({
        title: "Settings updated",
        description: "Email settings have been updated successfully.",
      });
    } catch (error) {
      console.error("Error updating settings:", error);
      toast({
        title: "Update failed",
        description: "There was an error updating the settings.",
        variant: "destructive",
      });
    }
  };

  // Handle API settings submission
  const onApiSubmit = async (data: ApiSettingsFormValues) => {
    try {
      // In a real implementation, we would update via API
      // await adminApi.updateApiSettings(data);
      
      console.log("Updating API settings:", data);
      
      toast({
        title: "Settings updated",
        description: "API settings have been updated successfully.",
      });
    } catch (error) {
      console.error("Error updating settings:", error);
      toast({
        title: "Update failed",
        description: "There was an error updating the settings.",
        variant: "destructive",
      });
    }
  };

  return (
    <motion.div
      className="space-y-6"
      variants={pageContainerVariants}
      initial="hidden"
      animate="visible"
    >
      <div>
        <h1 className="text-2xl font-bold text-white">System Settings</h1>
        <p className="text-slate-400">Configure platform settings and preferences</p>
      </div>

      <Card className="bg-slate-800 border-slate-700">
        <CardHeader className="pb-3">
          <CardTitle className="text-white">Settings</CardTitle>
          <CardDescription>
            Manage all aspects of the platform configuration
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="general" value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid grid-cols-4 md:grid-cols-7 mb-6 bg-slate-900">
              <TabsTrigger value="general" className="data-[state=active]:bg-amber-500 data-[state=active]:text-black">
                <Server size={16} className="mr-2" />
                <span className="hidden sm:inline">General</span>
              </TabsTrigger>
              <TabsTrigger value="email" className="data-[state=active]:bg-amber-500 data-[state=active]:text-black">
                <Mail size={16} className="mr-2" />
                <span className="hidden sm:inline">Email</span>
              </TabsTrigger>
              <TabsTrigger value="security" className="data-[state=active]:bg-amber-500 data-[state=active]:text-black">
                <Shield size={16} className="mr-2" />
                <span className="hidden sm:inline">Security</span>
              </TabsTrigger>
              <TabsTrigger value="api" className="data-[state=active]:bg-amber-500 data-[state=active]:text-black">
                <Globe size={16} className="mr-2" />
                <span className="hidden sm:inline">API</span>
              </TabsTrigger>
              <TabsTrigger value="billing" className="data-[state=active]:bg-amber-500 data-[state=active]:text-black">
                <CreditCard size={16} className="mr-2" />
                <span className="hidden sm:inline">Billing</span>
              </TabsTrigger>
              <TabsTrigger value="notifications" className="data-[state=active]:bg-amber-500 data-[state=active]:text-black">
                <Bell size={16} className="mr-2" />
                <span className="hidden sm:inline">Notifications</span>
              </TabsTrigger>
              <TabsTrigger value="logs" className="data-[state=active]:bg-amber-500 data-[state=active]:text-black">
                <FileText size={16} className="mr-2" />
                <span className="hidden sm:inline">Logs</span>
              </TabsTrigger>
            </TabsList>
            
            {/* General Settings */}
            <TabsContent value="general">
              <Form {...generalForm}>
                <form onSubmit={generalForm.handleSubmit(onGeneralSubmit)} className="space-y-6">
                  <FormField
                    control={generalForm.control}
                    name="siteName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Site Name</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Enter site name" 
                            className="bg-slate-900 border-slate-700"
                            {...field} 
                          />
                        </FormControl>
                        <FormDescription className="text-slate-500">
                          This is the name displayed throughout the application.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={generalForm.control}
                    name="siteDescription"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Site Description</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Enter site description" 
                            className="bg-slate-900 border-slate-700 min-h-[80px]"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={generalForm.control}
                    name="supportEmail"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Support Email</FormLabel>
                        <FormControl>
                          <Input 
                            type="email"
                            placeholder="Enter support email" 
                            className="bg-slate-900 border-slate-700"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={generalForm.control}
                      name="defaultUserRole"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Default User Role</FormLabel>
                          <Select 
                            onValueChange={field.onChange} 
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger className="bg-slate-900 border-slate-700">
                                <SelectValue placeholder="Select a role" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent className="bg-slate-900 border-slate-700">
                              <SelectItem value="user" className="text-white">User</SelectItem>
                              <SelectItem value="admin" className="text-white">Admin</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={generalForm.control}
                      name="maxLoginAttempts"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Max Login Attempts</FormLabel>
                          <FormControl>
                            <Input 
                              type="number"
                              min={1}
                              max={10}
                              className="bg-slate-900 border-slate-700"
                              {...field}
                              onChange={(e) => field.onChange(parseInt(e.target.value))}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="space-y-4">
                    <FormField
                      control={generalForm.control}
                      name="maintenanceMode"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border border-slate-700 p-3 shadow-sm">
                          <div className="space-y-0.5">
                            <FormLabel>Maintenance Mode</FormLabel>
                            <FormDescription className="text-slate-500">
                              Enable maintenance mode to prevent user access.
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={generalForm.control}
                      name="allowNewRegistrations"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border border-slate-700 p-3 shadow-sm">
                          <div className="space-y-0.5">
                            <FormLabel>Allow New Registrations</FormLabel>
                            <FormDescription className="text-slate-500">
                              Allow new users to register on the platform.
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  {generalForm.formState.isDirty && (
                    <Alert className="bg-amber-500/10 border-amber-500/20 text-amber-400">
                      <AlertCircle className="h-4 w-4" />
                      <AlertTitle>Unsaved Changes</AlertTitle>
                      <AlertDescription>
                        You have unsaved changes. Save to apply them.
                      </AlertDescription>
                    </Alert>
                  )}
                  
                  <div className="flex justify-end">
                    <Button type="submit" className="btn-primary">
                      <Save size={16} className="mr-2" />
                      Save Changes
                    </Button>
                  </div>
                </form>
              </Form>
            </TabsContent>
            
            {/* Email Settings */}
            <TabsContent value="email">
              <Form {...emailForm}>
                <form onSubmit={emailForm.handleSubmit(onEmailSubmit)} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={emailForm.control}
                      name="smtpHost"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>SMTP Host</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="e.g. smtp.gmail.com" 
                              className="bg-slate-900 border-slate-700"
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={emailForm.control}
                      name="smtpPort"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>SMTP Port</FormLabel>
                          <FormControl>
                            <Input 
                              type="number"
                              placeholder="e.g. 587" 
                              className="bg-slate-900 border-slate-700"
                              {...field}
                              onChange={(e) => field.onChange(parseInt(e.target.value))}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={emailForm.control}
                      name="smtpUsername"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>SMTP Username</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="Enter SMTP username" 
                              className="bg-slate-900 border-slate-700"
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={emailForm.control}
                      name="smtpPassword"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>SMTP Password</FormLabel>
                          <FormControl>
                            <Input 
                              type="password"
                              placeholder="Enter SMTP password" 
                              className="bg-slate-900 border-slate-700"
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={emailForm.control}
                      name="senderEmail"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Sender Email</FormLabel>
                          <FormControl>
                            <Input 
                              type="email"
                              placeholder="Enter sender email" 
                              className="bg-slate-900 border-slate-700"
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={emailForm.control}
                      name="senderName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Sender Name</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="Enter sender name" 
                              className="bg-slate-900 border-slate-700"
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={emailForm.control}
                    name="enableEmailVerification"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border border-slate-700 p-3 shadow-sm">
                        <div className="space-y-0.5">
                          <FormLabel>Email Verification</FormLabel>
                          <FormDescription className="text-slate-500">
                            Require email verification for new accounts.
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  
                  {emailForm.formState.isDirty && (
                    <Alert className="bg-amber-500/10 border-amber-500/20 text-amber-400">
                      <AlertCircle className="h-4 w-4" />
                      <AlertTitle>Unsaved Changes</AlertTitle>
                      <AlertDescription>
                        You have unsaved changes. Save to apply them.
                      </AlertDescription>
                    </Alert>
                  )}
                  
                  <div className="flex justify-end">
                    <Button type="submit" className="btn-primary">
                      <Save size={16} className="mr-2" />
                      Save Changes
                    </Button>
                  </div>
                </form>
              </Form>
            </TabsContent>
            
            {/* API Settings */}
            <TabsContent value="api">
              <Form {...apiForm}>
                <form onSubmit={apiForm.handleSubmit(onApiSubmit)} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={apiForm.control}
                      name="apiRateLimit"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>API Rate Limit</FormLabel>
                          <FormControl>
                            <Input 
                              type="number"
                              min={10}
                              max={1000}
                              className="bg-slate-900 border-slate-700"
                              {...field}
                              onChange={(e) => field.onChange(parseInt(e.target.value))}
                            />
                          </FormControl>
                          <FormDescription className="text-slate-500">
                            Maximum requests per minute per user.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={apiForm.control}
                      name="apiTokenExpiry"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>API Token Expiry</FormLabel>
                          <FormControl>
                            <Input 
                              type="number"
                              min={1}
                              max={30}
                              className="bg-slate-900 border-slate-700"
                              {...field}
                              onChange={(e) => field.onChange(parseInt(e.target.value))}
                            />
                          </FormControl>
                          <FormDescription className="text-slate-500">
                            Number of days until API tokens expire.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="space-y-4">
                    <FormField
                      control={apiForm.control}
                      name="enableApiLogging"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border border-slate-700 p-3 shadow-sm">
                          <div className="space-y-0.5">
                            <FormLabel>API Logging</FormLabel>
                            <FormDescription className="text-slate-500">
                              Log all API requests for auditing purposes.
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={apiForm.control}
                      name="allowCors"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border border-slate-700 p-3 shadow-sm">
                          <div className="space-y-0.5">
                            <FormLabel>Allow CORS</FormLabel>
                            <FormDescription className="text-slate-500">
                              Enable Cross-Origin Resource Sharing for the API.
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  {apiForm.watch("allowCors") && (
                    <FormField
                      control={apiForm.control}
                      name="corsOrigins"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>CORS Origins</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Enter allowed origins (one per line)" 
                              className="bg-slate-900 border-slate-700 min-h-[80px]"
                              {...field} 
                            />
                          </FormControl>
                          <FormDescription className="text-slate-500">
                            List allowed origins, one per line (e.g., https://example.com).
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  )}
                  
                  {apiForm.formState.isDirty && (
                    <Alert className="bg-amber-500/10 border-amber-500/20 text-amber-400">
                      <AlertCircle className="h-4 w-4" />
                      <AlertTitle>Unsaved Changes</AlertTitle>
                      <AlertDescription>
                        You have unsaved changes. Save to apply them.
                      </AlertDescription>
                    </Alert>
                  )}
                  
                  <div className="flex justify-end">
                    <Button type="submit" className="btn-primary">
                      <Save size={16} className="mr-2" />
                      Save Changes
                    </Button>
                  </div>
                </form>
              </Form>
            </TabsContent>
            
            {/* Other tabs would be implemented similarly */}
            <TabsContent value="security">
              <div className="p-8 text-center text-slate-400">
                <Shield size={48} className="mx-auto mb-4 opacity-50" />
                <h3 className="text-lg font-medium text-white mb-2">Security Settings</h3>
                <p>Security settings will be implemented in a future update.</p>
              </div>
            </TabsContent>
            
            <TabsContent value="billing">
              <div className="p-8 text-center text-slate-400">
                <CreditCard size={48} className="mx-auto mb-4 opacity-50" />
                <h3 className="text-lg font-medium text-white mb-2">Billing Settings</h3>
                <p>Billing settings will be implemented in a future update.</p>
              </div>
            </TabsContent>
            
            <TabsContent value="notifications">
              <div className="p-8 text-center text-slate-400">
                <Bell size={48} className="mx-auto mb-4 opacity-50" />
                <h3 className="text-lg font-medium text-white mb-2">Notification Settings</h3>
                <p>Notification settings will be implemented in a future update.</p>
              </div>
            </TabsContent>
            
            <TabsContent value="logs">
              <div className="p-8 text-center text-slate-400">
                <FileText size={48} className="mx-auto mb-4 opacity-50" />
                <h3 className="text-lg font-medium text-white mb-2">System Logs</h3>
                <p>System logs will be implemented in a future update.</p>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </motion.div>
  );
}
